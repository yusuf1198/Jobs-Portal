<?php 

date_default_timezone_set('asia/karachi');
include("./constants/db_config.php");
include("./constants/values.php");  

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>Green Jobs</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <link href="./css/first_link.css" rel="stylesheet">
  <link href="./css/second_link.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet"> 
  <link rel="stylesheet" href="./css/testing.css">
 
</head>

<body>
  <a href="./constants/db_config.php"></a>
  <div class="container-xxl bg-white p-0">
    <!-- Spinner Start -->
    <div id="spinner"
      class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
      <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
        <span class="sr-only">Loading...</span>
      </div>
    </div>
    <!-- Spinner End -->

    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0" id="navData">

    </nav>
    <!-- Navbar End -->
    <section style="height: 65rem;">
      <div class="cards">
        <article class="information [ card ]">
          <span class="tag">Feature</span>
          <h2 class="title">Unleash Your Potential: Tell Us about yourself!</h2>
          <p class="info">You can also add your personal data if you are applying on Green Jobs </p>
          
          <?php 
         
             $query = "SELECT * FROM `resume` WHERE `phone` = '$cell'";
             $result = mysqli_query($con, $query);
             if (mysqli_num_rows($result) > 0) {
             
           ?>
           <a href="./resume.php" style="color: white;"><button class="button1 btn-outline-success">
            <div class="d-flex"> 
            
            <span>View resume</span>
            </a>
            </div>
                  <?php
                      } else {
                  ?>
                  <a href="./add_Cv.php" style="color: white;"><button class="button1 btn-outline-success">
                <div class="d-flex">  
                <span>Add resume</span>
                </a>
                </div>
                <?php
                    }
                ?>
              <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="none">
                <path d="M0 0h24v24H0V0z" fill="none" />
                <path d="M16.01 11H4v2h12.01v3L20 12l-3.99-4v3z" fill="currentColor" />
              </svg>
            </button>
          
        </article>
        <!----------------------------------- cv testing ------------------------------------------------------------->
        <article class="information [ card ]">
          <span class="tag">Feature</span>
          <h2 class="title">Unleash Your Potential: Tell Us about yourself!</h2>
          <p class="info">You can also add your personal data if you are applying on Green Jobs </p>
          
          <?php 
         
             $query = "SELECT * FROM `apply_request` WHERE `phone` = '$cell'";
             $result = mysqli_query($con, $query);
             if (mysqli_num_rows($result) > 0) {
             
           ?>
            <button class="button1 btn-outline-success" >
            <div class="d-flex"> 
            
            <span>Request pending....</span> 
            </div> 
            <?php  } else { ?>
             <button class="button1 btn-outline-success" onclick="sendRequest()">
            <div class="d-flex"> 
            
            <span>Send cv request</span>
            </div>
              <?php }?>
              <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="none">
                <path d="M0 0h24v24H0V0z" fill="none" />
                <path d="M16.01 11H4v2h12.01v3L20 12l-3.99-4v3z" fill="currentColor" />
              </svg>
            </button>
          
        </article>
        <article class="plan [ card ]">
          <div class="inner">
            <span class="pricing">
              <span>
                0Rs <small>/ cv</small>
              </span>
            </span>
            <h2 class="title">Upload Cv here</h2>
            <p class="info">Submit Your CV for Expert Review!</p>
            <ul class="features">
              <span><img width="20" height="20" src="https://img.icons8.com/windows/32/FAB005/checked--v1.png"
                  alt="checked--v1" /> Real-time <strong>Updates</strong></span>

              <span><img width="20" height="20" src="https://img.icons8.com/windows/32/FAB005/checked--v1.png"
                  alt="checked--v1" /> Show <strong>vulnerabilities</strong></span>

              <span><img width="20" height="20" src="https://img.icons8.com/windows/32/FAB005/checked--v1.png"
                  alt="checked--v1" /> Suggest <strong>Changes</strong></span>

              <span > <img width="20" height="20" src="https://img.icons8.com/windows/32/FAB005/checked--v1.png"
                  alt="checked--v1" />Helps you to <strong>Improve</strong></span>
            </ul>
            <?php
                    $check = mysqli_query($con, "SELECT * FROM `cvrequest` WHERE `phone` = '$cell'");
                    $row = mysqli_fetch_array($check); 
                    if($row){
                    ?> 
                              <button class='button1 btn btn-info'>
                                  <span>waiting for response...</span>
                              </button> 
                            <?php
                    }else {
                            ?> 
                            <a href='javascript:void(0);' onclick='openUploadModal()' style='color: white;'>
                              <button class='button1 btn-outline-success'>
                                  <span>Upload CV</span>
                              </button>
                            </a>
                            <?php
                            
                    }
                            ?>
        </article>
      </div>
    </section>

          <div class="modal fade" id="uploadModal" tabindex="-1" role="dialog" aria-labelledby="uploadModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="uploadModalLabel">Request skill assessment test !</h5>
                </div>
                <div class="modal-body"> 
                    <div class="mb-3">
                    <details>
                            <summary>Terms and condition</summary>
                            <pre><span style="font-size: 20px; color: black;">Self-Discovery:</span> 
"Using Skill assessment tests
provide valuable insights into
your abilities and competencies.
By understanding your strengths 
and weaknesses,you gain a
clearer picture of your
professional identity."

 <span style="font-size: 20px; color: black">Competitive Edge:</span>                              
"The versatility of <span style="color: black;">"<u>Green job test</u>"</span> is 
impressive. It help you visible in
almost all the jobs you applied
in green jobs"

 <span style="font-size: 20px; color: black">Fee:</span>                           
"By charging a nominal fee, we ensure the
highest standards of assessment, backed
by thorough research and analysis."</pre>
                        </details>
                    </div>
                    <button class="btn btn-primary mt-3" name="upload" onclick = "testingCv()" style="margin-left: 15px;">Send</button>
                </div>
              </div>
            </div>
          </div>
          <input type="hidden" id="screenName" value="testing.php">

    <script src="./css/code.jquery.com_jquery-3.4.1.min.js"></script>
    <script src="./css/cdn.jsdelivr.net_npm_bootstrap@5.0.0_dist_js_bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="./js/sweetalert.js"></script>
    <script>
    // Function to open the modal
    function openUploadModal() {
      $('#uploadModal').modal('show');
    }
  </script>
    <script>
      $(document).ready(function () {
        screenInsert();
        navBar();


      });
      function sendRequest(){ 
           
            // var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/cv_testing.php",
                data: {
                    // "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                    if (data == 200) { 
                      locationReload();
                    }else{
                      locationReload();
                    }

                }, 
            });
    }
      function screenInsert(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/screenInsert.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                    if (data == 200) { 
                      Swal.fire({
                                title: "Error",
                                text: "There is some problem from your side",
                                icon: "warning",
                                confirmButtonColor: "#3085d6",
                                confirmButtonText: "Oops!",
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    locationReload();
                                }
                            });
                    }
                    render();
                },

            });
    }
        function render(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/render.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                

                },

            });
    }
      function navBar() {
        $.ajax({
          type: "GET",
          url: "./backend/navBar/navBar.php",
          data: {},
          success: function (data) {
            if (data == 200) {

              var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="testing.php" class="nav-item nav-link">Upload Cv</a><div class="nav-item dropdown"><a href="resume.php" class="nav-item nav-link">view resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';

              $("#navData").append(html);
            } else {

              var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="testing.php" class="nav-item nav-link">Upload Cv</a><a href="add_Cv.php" class="nav-item nav-link">Add resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';

              $("#navData").append(html);
            }

          },

        });
      }
              function testingCv() {
              
            Swal.fire({
                title: "Loading...",
                text: "Please wait",
                allowOutsideClick: false,
                showCancelButton: false,
                showConfirmButton: false,
                onBeforeOpen: () => {
                    Swal.showLoading();
                },
            });

            setTimeout(function () {
                $.ajax({
                    type: "POST",
                    url: "./backend/Cv/testingCv.php",
                    data: {},
                    contentType: false,
                    processData: false,
                    success: function (data) { 
                        Swal.close(); 
                        if (data == 420) {
                            Swal.fire({
                                title: "Error",
                                text: "There is some problem from your side",
                                icon: "warning",
                                confirmButtonColor: "#3085d6",
                                confirmButtonText: "Oops!",
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    locationReload();
                                }
                            });
                        } else {
                            Swal.fire({
                                title: "Request submitted",
                                text: "You will get your response soon",
                                icon: "success",
                                confirmButtonColor: "#3085d6",
                                confirmButtonText: "Done!",
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    locationReload();
                                }
                            });
                        }
                    },
                });
            }, 3000);  
          }
          function locationReload(){
            window.location.reload();
        }
 
    </script>

    <script src="js/main.js"></script>

</body>

</html>