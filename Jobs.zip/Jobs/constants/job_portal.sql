-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 26, 2024 at 07:16 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `job_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `apply_request`
--

CREATE TABLE `apply_request` (
  `id` int(10) NOT NULL,
  `cv_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `guardian` varchar(255) NOT NULL,
  `post` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `whatsapp_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `about_Me` varchar(100) NOT NULL,
  `work_Exp` varchar(100) NOT NULL,
  `education` varchar(100) NOT NULL,
  `languages` varchar(100) NOT NULL,
  `expected_salary` varchar(100) NOT NULL,
  `current_salary` varchar(100) NOT NULL,
  `city_of_interest` varchar(10) NOT NULL,
  `projects` varchar(11) NOT NULL,
  `responseStatus` varchar(255) NOT NULL DEFAULT 'pending',
  `percentage` varchar(100) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cvrequest`
--

CREATE TABLE `cvrequest` (
  `id` int(10) NOT NULL,
  `cv_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `guardian` varchar(255) NOT NULL,
  `post` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `whatsapp_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `about_Me` varchar(100) NOT NULL,
  `work_Exp` varchar(100) NOT NULL,
  `education` varchar(100) NOT NULL,
  `languages` varchar(100) NOT NULL,
  `expected_salary` varchar(100) NOT NULL,
  `current_salary` varchar(100) NOT NULL,
  `city_of_interest` varchar(10) NOT NULL,
  `projects` varchar(11) NOT NULL,
  `responseStatus` varchar(255) NOT NULL DEFAULT 'pending',
  `percentage` varchar(100) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `profession` varchar(255) NOT NULL,
  `Salary` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL,
  `Apply_before` varchar(255) NOT NULL,
  `education` varchar(255) NOT NULL,
  `start_time` varchar(100) NOT NULL,
  `end_time` varchar(100) NOT NULL,
  `adress` varchar(255) NOT NULL,
  `status` varchar(100) NOT NULL,
  `created_on` date NOT NULL,
  `updated_on` date NOT NULL,
  `deleted_on` date NOT NULL,
  `cell` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `title`, `company`, `profession`, `Salary`, `experience`, `Apply_before`, `education`, `start_time`, `end_time`, `adress`, `status`, `created_on`, `updated_on`, `deleted_on`, `cell`) VALUES
(3, 'Manager', 'Green pay smc', 'Developer', 'USD 50000', '1 Years', '2024-05-29', 'masters', '09:00', '18:00', 'anywhere block something steet 14', 'ON SITE', '2026-05-24', '2026-05-24', '2026-05-24', '03345566999');

-- --------------------------------------------------------

--
-- Table structure for table `req_jobs`
--

CREATE TABLE `req_jobs` (
  `id` int(10) NOT NULL,
  `j_id` varchar(100) NOT NULL,
  `j_title` varchar(100) NOT NULL,
  `j_address` varchar(100) NOT NULL,
  `j_company` varchar(100) NOT NULL,
  `j_status` varchar(100) NOT NULL,
  `j_strt_timing` varchar(100) NOT NULL,
  `j_end_timing` varchar(100) NOT NULL,
  `apply_before` varchar(100) NOT NULL,
  `j_salary` varchar(100) NOT NULL,
  `j_created_on` varchar(100) NOT NULL,
  `response` varchar(100) NOT NULL DEFAULT 'no-response',
  `u_name` varchar(100) NOT NULL,
  `u_guardian` varchar(100) NOT NULL,
  `u_post` varchar(50) NOT NULL,
  `u_phone` varchar(11) NOT NULL,
  `u_whatsapp` varchar(11) NOT NULL,
  `u_email` varchar(50) NOT NULL,
  `remarks` varchar(255) NOT NULL DEFAULT 'pending',
  `u_address` varchar(50) NOT NULL,
  `about_me` text NOT NULL,
  `work_exp` varchar(50) NOT NULL,
  `u_education` varchar(50) NOT NULL,
  `languages` varchar(50) NOT NULL,
  `expected_salary` varchar(50) NOT NULL,
  `current_salary` varchar(50) NOT NULL,
  `city_of_interest` varchar(50) NOT NULL,
  `project` varchar(50) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_on` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `req_jobs`
--

INSERT INTO `req_jobs` (`id`, `j_id`, `j_title`, `j_address`, `j_company`, `j_status`, `j_strt_timing`, `j_end_timing`, `apply_before`, `j_salary`, `j_created_on`, `response`, `u_name`, `u_guardian`, `u_post`, `u_phone`, `u_whatsapp`, `u_email`, `remarks`, `u_address`, `about_me`, `work_exp`, `u_education`, `languages`, `expected_salary`, `current_salary`, `city_of_interest`, `project`, `created_on`, `updated_on`, `deleted_on`) VALUES
(5, '3', 'MANAGER', 'ANYWHERE BLOCK SOMETHING STEET 14', 'GREEN PAY SMC', 'ON SITE', '09:00', '18:00', '2024-05-29', 'USD 50000', '2026-05-24', 'sorry we hire someone else', 'Muhammad Yousaf', 'Ghulam sarwar', 'Developer', '03345566999', '03060840812', 'leaderthe644@gmail.com', 'Rejected', '', 'I am an expert developer with over 4 years of experience ', '4Year', 'Masters', 'English', '150000', '120000', 'Bahawalnagar', 'nothing at this time', '2026-05-24 07:00:00', '2026-05-24 07:00:00', '0');

-- --------------------------------------------------------

--
-- Table structure for table `resume`
--

CREATE TABLE `resume` (
  `cv_id` int(20) NOT NULL,
  `name` text NOT NULL DEFAULT '"Name"',
  `guardian` varchar(255) NOT NULL,
  `post` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `whatsapp_number` varchar(15) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `country` varchar(50) NOT NULL,
  `about_Me` varchar(255) NOT NULL,
  `work_Exp` varchar(255) NOT NULL,
  `education` varchar(255) NOT NULL,
  `languages` varchar(255) NOT NULL,
  `expected_salary` int(20) NOT NULL,
  `current_salary` int(20) NOT NULL,
  `city_of_interest` text NOT NULL,
  `projects` text NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_on` varchar(255) DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `resume`
--

INSERT INTO `resume` (`cv_id`, `name`, `guardian`, `post`, `phone`, `whatsapp_number`, `email`, `address`, `country`, `about_Me`, `work_Exp`, `education`, `languages`, `expected_salary`, `current_salary`, `city_of_interest`, `projects`, `created_on`, `updated_on`, `deleted_on`) VALUES
(1, 'Muhammad Yousaf', 'Ghulam sarwar', 'Developer', '03345566999', '03060840812', 'leaderthe644@gmail.com', 'address anywhere ', 'Pakistan', 'I am an expert developer with over 4 years of experience ', '4Year', 'Masters', 'English', 150000, 120000, 'Bahawalnagar', 'nothing at this time', '2026-05-24 07:00:00', '2026-05-24 07:00:00', '0');

-- --------------------------------------------------------

--
-- Table structure for table `screens`
--

CREATE TABLE `screens` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `count` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `screens`
--

INSERT INTO `screens` (`id`, `name`, `date`, `count`) VALUES
(1, 'testing.php', '31-01-24', 56),
(2, 'index.php', '26-05-24', 26),
(3, 'add_job.php', '26-05-24', 7),
(4, 'add_cv.php', '26-05-24', 3),
(5, 'resume.php', '26-05-24', 4),
(6, 'apply_job.php', '26-05-24', 3),
(7, 'recommended.php', '26-05-24', 2),
(8, 'update_resume.php', '26-05-24', 1),
(9, 'company_jobs.php', '26-05-24', 4),
(10, 'appliedJobs.php', '26-05-24', 5),
(11, 'update_job.php', '26-05-24', 3),
(12, 'applicants.php', '26-05-24', 3);

-- --------------------------------------------------------

--
-- Table structure for table `usercount`
--

CREATE TABLE `usercount` (
  `id` int(10) NOT NULL,
  `usercell` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usercount`
--

INSERT INTO `usercount` (`id`, `usercell`) VALUES
(1, '03060840812'),
(2, '03055585558'),
(3, '03345566999');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `apply_request`
--
ALTER TABLE `apply_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cvrequest`
--
ALTER TABLE `cvrequest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `req_jobs`
--
ALTER TABLE `req_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resume`
--
ALTER TABLE `resume`
  ADD PRIMARY KEY (`cv_id`);

--
-- Indexes for table `screens`
--
ALTER TABLE `screens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usercount`
--
ALTER TABLE `usercount`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `apply_request`
--
ALTER TABLE `apply_request`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cvrequest`
--
ALTER TABLE `cvrequest`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `req_jobs`
--
ALTER TABLE `req_jobs`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `resume`
--
ALTER TABLE `resume`
  MODIFY `cv_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `screens`
--
ALTER TABLE `screens`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `usercount`
--
ALTER TABLE `usercount`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
