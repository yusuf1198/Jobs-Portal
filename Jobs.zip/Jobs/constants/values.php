<?php  
 $username = 'yousaf';
 $password = '00000';
 $cell = '03345566999'; 
 $phone = '03345566999';  
 $balance = '500'; 
?> 