<!DOCTYPE html>
<html lang="en">
<?php 
session_start();
include("./constants/db_config.php");
include("./constants/values.php");
    $cell = $cell; 
?>
<head>
    <meta charset="utf-8">
    <title>Green Jobs</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <link href="./css/first_link.css" rel="stylesheet"> 
    <link href="./css/second_link.css" rel="stylesheet">  
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet"> 
    <link href="css/bootstrap.min.css" rel="stylesheet"> 
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

            <input type="hidden" id="userCell" value = "<?php echo $cell ?>">
         <!-- Navbar Start -->
         <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0" id="navData">
           
        </nav>
        <!-- Header End -->
        <h1 class="text-center  wow fadeInUp" data-wow-delay="0.1s">Your Jobs</h1>
      <div class="container-xxl">
            <div class="container">
                <div class="tab-content">
                    <div id="tab-1" class="tab-pane fade show p-0 active" > 
                        <div id="showData">
                        <!-- data will append here -->
                        </div>
                    </div>
                </div>
                <!-- Jobs End -->
            </div>
        </div>
    </div>
    <input type="hidden" id="screenName" value="company_jobs.php">
    <!-- JavaScript Libraries -->
    <script src="./css/code.jquery.com_jquery-3.4.1.min.js"></script>
    <script src="./css/cdn.jsdelivr.net_npm_bootstrap@5.0.0_dist_js_bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script> 
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
<script>
     $(document).ready(function() { 
            screenInsert();
            Company_jobs(); 
            navBar();

            });
            function screenInsert(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/screenInsert.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                    if (data == 200) { 
                        render();
                    }else{
                        render();
                    }

                },

            });
    }
        function render(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/render.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                

                },

            });
    }
            function navBar(){ 
        $.ajax({
            type: "GET",
            url: "./backend/navBar/navBar.php",
            data: {  },
            success: function (data) {
                if (data == 200) {

                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="resume.php" class="nav-item nav-link">view resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';

                   
                          $("#navData").append(html);
                }else {
                    
                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="add_Cv.php" class="nav-item nav-link">Add resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';
                    
                    $("#navData").append(html); 
                }

            },

        });
    }
        function Company_jobs() { 
                var userCell      = document.getElementById("userCell").value; 

                $.ajax({
                    type: "POST",
                    url: "./backend/companyJobs/companyAjax.php",
                    data: { 
                        "userCell"      : userCell,  
                    },
                    success: function (data) {
                        if (data == 420) {
                        alert("something");
                         } 
                        else {
                          $.each(data, function (i, item) {
                              var created_on   = item.created_on;
                              var address      = item.adress;
                              var id           = item.id;
                              var Apply_before = item.Apply_before;
                              var Salary       = item.Salary;
                              var j_strt_timing       = item.j_strt_timing;
                              var j_end_timing       = item.j_end_timing;
                              var company      = item.company;
                              var status      = item.status;
                              var title        = item.title; 
                              $("#showData").append('<div class="job-item p-4 mb-4"><div class="row"><div class="col-sm-12 col-md-8 "><div class="text-start"><h6><b><b>' + title + '</b> <a href="update_job.php?id=' + item.id + '"><img width="25" height="25" src="https://img.icons8.com/flat-round/64/loop.png" alt="loop"/></a></b></h6><hr><p><img width="20" height="20" src="./img/building.png" alt="building"/><b>  ' + company + '</b><br></p></div></div><div class="col-sm-12 col-md-4 d-flex flex-column align-items-start align-items-md-end justify-content-center"><span class="text-truncate me-0"><img width="20" height="20" src="./img/add-bookmark.png" alt="add-bookmark"/>' + item.status + '</span><span class="text-truncate me-3"><img width="20" height="20" src="./img/time--v1.png" alt="time--v1"/>' + j_strt_timing + ' to ' + j_end_timing + '</span><span class="text-truncate me-0"><img width="20" height="20" src="./img/money-bag.png" alt="money-bag"/>' + Salary + '</span><small class="text-truncate"><img width="18" height="18" src="./img/calendar.png" alt="calendar"/><b>Apply Before:</b>' + Apply_before + '</small><p><img width="16" height="16" src="./img/marker.png" alt="marker" /><b><span style="font-size: 15px ;" >Location:</span>  </b>' + address + '<br><div class="d-flex mb-3"><a class="btn btn-primary" href="applicants.php?jobid=' + item.id + '">Applicants</a></div><span class="text-truncate me-3"><img width="16" height="16" src="./img/calendar.png" alt="calendar"/><b>Posted on:</b> ' + created_on + '</span></p></div></div></div>');
                        });
                    }

                    },
                    error: function (type, obj, msg) {
                        //alert(msg);
                    },
                });
            }
    </script>
    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>