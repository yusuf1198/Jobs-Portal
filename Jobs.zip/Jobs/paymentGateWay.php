
<?php
date_default_timezone_set("Asia/Karachi");
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET,HEAD,OPTIONS,POST,PUT");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization");
include('./constants/db_config.php');
include('./constants/values.php');

/////////////////////////////////// VARIABLES THAT WE G0T FROM AJAX ////////////////////////////
 

$userId                    = $_POST['userId'];
$userCell                  = $_POST['userCell'];
$userName                  = $_POST['userName'];
$Profession                = $_POST['Profession']; 
$userPass                  = $_POST['mPinCode'];
$type                      = $_POST['type'];
$date                      = $_POST['date'];
$Company_name              = $_POST['Company_name'];
$Job_title                 = $_POST['Job_title'];
$customerAddress           = $_POST['customerAddress'];
$Salary_range              = $_POST['Salary_range'];
$jobtype                   = $_POST['jobtype'];
$Education                 = $_POST['Education'];
$experience                = $_POST['experience'];
$country                   = $_POST['country'];
$starting                    = $_POST['starting'];
$ending                    = $_POST['ending'];
$amount                    = $_POST['amount'];

$userRegisteredCell          = $_POST['userRegisteredCell'];
$OTP                         = $_POST['userRegistDeviceString'];
$secureId                    = $_POST['userRegistSecureId'];
$phoneModel                  = $_POST['userRegistPhoneModel'];

$current_date = date("d-m-y");

session_start();
$cell                       =  $_SESSION['cell'];        

         // 03320000030
         $toUserCell = "03320000030";  // babar ka account number ha
         $bankAccName = "Your job for ".$Job_title." in Rs:".$amount." sucessfully added ";
         $narration =  "Your job for ".$Job_title." in Rs:".$amount." sucessfully added ";
         $policyId = 0;
         $policyPercentage = "0.0";
         $coorporateId = 0;
         $isPostPaidNumber = "Prepaid";
         $pckOfferId = "0";
         $pckOfferName = "";
         $billReferenceNumber = "0";
         $pckServiceCharges = 0;
         $totalServiceCharges = 0;
         $bankCode             = '0';
         $beneAccountNo        = '0';
         $beneAcconuntName     = '';

         $NTNumber = "0";
         $cnicDate = date("Y-m-d");
         // $userCity = "BWN";

         $curl = curl_init();
         curl_setopt_array($curl, array(
             CURLOPT_URL => "https://eduvalley.pk/greenApp/ajaxApi/payLoadPck.php",
             CURLOPT_RETURNTRANSFER => true,
             CURLOPT_ENCODING => '',
             CURLOPT_MAXREDIRS => 10,
             CURLOPT_TIMEOUT => 0,
             CURLOPT_FOLLOWLOCATION => true,
             CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
             CURLOPT_CUSTOMREQUEST => 'POST',
             CURLOPT_POSTFIELDS =>'{
                 "userId": "'.$userId.'",
                 "userName": "'.$userName.'",
                 "pincode": "'.$userPass.'",
                 "userRegistSecureId": "'.$secureId.'",
                 "userRegistDeviceString": "'.$OTP.'",
                 "userRegistPhoneModel": "'.$phoneModel.'",
                 "creditId": "'.$userCell.'",
                 "debitId": "'.$toUserCell.'",
                 "amount": "'.$amount.'",
                 "bankAccountName": "'.$bankAccName.'",
                 "policyId": "'.$policyId.'",
                 "policyPercentage": "'.$policyPercentage.'",
                 "coorporateId": "'.$coorporateId.'",
                 "isPostPaidNumber": "'.$isPostPaidNumber.'",
                 "pckOfferId": "'.$pckOfferId.'",
                 "pckOfferName": "'.$pckOfferName.'",
                 "narration": "'.$narration.'",
                 "billReferenceNumber": "'.$billReferenceNumber.'",
                 "pckServiceCharges": "'.$pckServiceCharges.'",
                 "totalServiceCharges": "'.$totalServiceCharges.'",
                 "bankCode": "'.$bankCode.'",
                 "beneAccountNo": "'.$beneAccountNo.'",
                 "beneAcconuntName": "'.$beneAcconuntName.'",
                 "billTelNumber": "'.$userCell.'"
             }',
             CURLOPT_HTTPHEADER => array(
                 'content-type: application/json',
                 'Accept: application/json'
             ),
         ));
         //Execute
         $response  = curl_exec($curl);
         // print_r($response);
         //Error
         $errUpdate = curl_error($curl);
         curl_close($curl);

         if($errUpdate) 
         {
             $data = array('message' => 'INTERNAL SERVER ERROR!! PAYMENT REJECTED Due To Internal Server Error. Sorry For Inconvenience, Please Try Again Later...', 'status' => false, 'code' => '500');
         }
         else
         {
             $responseDecoded = json_decode($response);
             $responseCode    = $responseDecoded->code;
             // $responseCode    = "200";
             $responseMessage = $responseDecoded->message;

             if($responseCode == "200") 
             {
                 $updatedBalanceFrom = $responseDecoded->accountBalance;
                 $userSecureId = $responseDecoded->userSecureId;
                 $newOtp = $responseDecoded->userDeviceString;
                 $userPhoneModel = $responseDecoded->userPhoneModel;
                 $userType = $responseDecoded->userType;

                 /////******************** YOUR DATA SAVING AFTER SUCCESSFULL PAYMENT **************///////////
                 
                 $query = "INSERT INTO `jobs`(`userId`, `userCell`, `userName`, `title`,`profession`,`company`,`payment_method`,`Salary`, `experience`, `Apply_before`, `education`, `start_time`, `end_time`, `adress`, `status`, `created_on`, `updated_on`, `deleted_on`, `cell`) VALUES ('$userId','$userCell','$userName','$Job_title','$Profession','$Company_name','$type','$Salary_range','$experience','$date','$Education','$starting','$ending','$customerAddress','$jobtype','$current_date','$current_date','0','$userCell')";  

                   $run1 = mysqli_query($con, $query);

                 $data = array('message' => $responseMessage, 'status' => true, 'code' => $responseCode, 'accountBalance' => $updatedBalanceFrom, 'userSecureId' => $userSecureId, 'userDeviceString' => $newOtp, 'userPhoneModel' => $userPhoneModel, 'userType' => $userType);
             }
             else  {
                 if($responseCode == "406")
                 {
                     $updatedBalanceFrom = $responseDecoded->accountBalance;
                     $userSecureId = $responseDecoded->userSecureId;
                     $newOtp = $responseDecoded->userDeviceString;
                     $userPhoneModel = $responseDecoded->userPhoneModel;
                     $userType = $responseDecoded->userType;

                     $data = array('message' => $responseMessage, 'status' => true, 'code' => $responseCode, 'accountBalance' => $updatedBalanceFrom, 'userSecureId' => $userSecureId, 'userDeviceString' => $newOtp, 'userPhoneModel' => $userPhoneModel, 'userType' => $userType);
                 } else {
                     $data = array('message' =>  $responseMessage, 'status' => false, 'code' => $responseCode);
                 }
             }
         }
         //***************************PAYMENT METHOD END *****************************
     $data = 200;

 header('content-type: application/json');
 echo json_encode($data);
?> 
