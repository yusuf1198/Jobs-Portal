<?php 

date_default_timezone_set('asia/karachi');
include("./constants/db_config.php");
include("./constants/values.php"); 
$UpdateID = htmlspecialchars($_GET['id']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Green Jobs</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <link href="./css/first_link.css" rel="stylesheet">
    <link href="./css/second_link.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
    
  @import url('./css/fonts_links.css'); 

.form-label {
    font-family: 'Noto Nastaliq Urdu', serif;
} 
        @import url('./css/fonts_links.css');

        .form-label {
            font-family: 'Noto Nastaliq Urdu', serif;
        }
        #scrollButton {
            display: none;
            height: 70px;
            width: 70px;
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 10px; 
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.7);
        }

        .modal-content {
            margin: 15% auto;
            padding: 20px;
            background-color: #fefefe;
            border: 1px solid #888;
            width: 80%;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner"
            class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar Start -->
        <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0" id="navData">
            
        </nav>
        <!-- Navbar End -->


        <?php 
    $ret = mysqli_query($con, "SELECT * FROM `jobs`  WHERE `id` = $UpdateID "); 
    while($row=mysqli_fetch_row($ret)) {
        ?>

        <!-- About Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="mb-3">
                    <label class="form-label">Company name کمپنی کا نام</label>
                    <input type="text" class="form-control" name="Company_name" id="Company_name" value="<?php echo $row['3']; ?>"
                        style="background-color: #ccc;" placeholder="Enter your company name" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Designation  عہدہ  </label>
                    <input type="text" class="form-control" name="Job_title"  id="Job_title" value="<?php echo $row['1']; ?>"
                        style="background-color: #ccc;" placeholder="Title for your job" required>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label">Job Type ملازمت کی قسم</label>
                        <select name="jobtype" id="jobtype" style="background-color: #ccc;" required
                            class="selectpicker show-tick form-control" data-live-search="false"
                            data-selected-text-format="count > 3" data-done-button="true" data-done-button-text="OK"
                            data-none-selected-text="All"> 
                            </option>
                            <option value="On site" data-content="<span class='label label-danger'>Part-time</span>"> Onsite موقے پر</option>
                            <option value="Remote" data-content="<span class='label label-success'>Freelance</span>">
                                Remote دور دراز کام</option>
                        </select>
                    </div>
                </div>
                <input type="hidden" id="updateId" value="<?php echo  $UpdateID ?>">
                <input type="hidden" id="userCell" value="<?php echo  $cell ?>">
                <div class="mb-3">
                    <label class="form-label"> Job Timing جاب ٹائمنگ</label>
                    <input type="text" name="Timing" id="Timing" value="<?php echo $row['9']; ?>" style="background-color: #ccc;"
                        class="form-control" placeholder="Timing" required>
                </div>

                <div class="mb-3 input-group">
                    <input type="text" class="form-control" name="Salary_range" id="Salary_range" value="<?php echo $row['4']; ?>"
                        style="background-color: #ccc;" placeholder="Salary تنخواہ"  required>
                    <div class="input-group-append">
                        <select class="form-select" name="currency" id="currency">
                            <option value="PKR">PKR</option>
                            <option value="USD">USD</option>
                            <option value="INR">INR</option>
                            <option value="Pound">Pound</option>
                            <option value="Daharam">Daharam</option>
                            <option value="Rayal">Rayal</option>
                            <!-- Add more currency options as needed -->
                        </select>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Education required تعلیم کی ضرورت ہے۔</label>
                    <input type="text" name="Education" id="Education" class="form-control" value="<?php echo $row['7']; ?>"
                        style="background-color: #ccc;" placeholder="Education" required>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label">Experience Required تجربہ درکار ہے۔</label>
                        <select name="experience" id="experience" required class="selectpicker show-tick form-control"
                            data-live-search="false" data-selected-text-format="count > 3" data-done-button="true"
                            data-done-button-text="OK" data-none-selected-text="All" required>
                            <option value="<?php echo $row['5']; ?>" selected>
                                <?php echo $row['5']; ?>
                            </option>
                            <option value="1 Years">1 Years</option>
                            <option value="2 Years">2 Years</option>
                            <option value="3 Years">3 Years</option>
                            <option value="4 Years">4 Years</option>
                            <option value="5 Years">5 Years</option>
                            <option value="10 Years">10 Years</option>
                        </select>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label">You Need آپ کو ضرورت ہے</label>
                        <select name="Profession" id="Profession" required class="selectpicker show-tick form-control"
                            data-live-search="false" data-selected-text-format="count > 3" data-done-button="true"
                            data-done-button-text="OK" data-none-selected-text="All">
                            <option value="None">None</option>
                            <option value="Developer">Developer</option>
                            <option value="Peon">Peon</option>
                            <option value="Normal_worker">Normal worker</option>
                            <option value="Doctor">Doctor</option>
                            <option value="Engineer">Engineer</option>
                        </select>
                    </div> 
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label class="form-label">Country ملک</label>
                        <select name="country" id="country" required class="selectpicker show-tick form-control"
                            data-live-search="true" required>
                            <option disabled value="">Select</option>
                            <option value="Pakistan">Pakistan</option>
                            <option value="India">India</option>
                            <option value="Afghanistan">Afghanistan</option>
                            <option value="Australia">Australia</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">Location پتہ</label>
                            <input name="city" id="city" value="<?php echo $row['8']; ?>" style="background-color: #ccc;" required
                                type="text" class="form-control" placeholder="Enter Address" required>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="mb-3">
                        <label class="form-label">Apply before اس سے پہلے درخواست دیں۔</label>
                        <div class="form-group">
                            <input type="date" name="Apply" id="datepicker" class="form-control"
                                value="<?php echo $row['6'];?>" placeholder="Select date" required>
                        </div>

                    </div>

                </div>
                <div class="col-sm-6">
                    <button type="submit" name="submit" onclick="Update_job()" class="btn btn-primary btn-lg">Update
                        Job</button>
                </div>
            </div>
        </div>
        <!-- About End -->
        <?php 
    }
        ?>
         <img width="40" height="40" id="scrollButton" onclick="openModal()" src="https://img.icons8.com/sf-black-filled/64/40C057/help.png" alt="help">

<div id="myModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <video width="100%" height="auto" controls>
            <source src="your-video-file.mp4" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    </div>
</div>
<input type="hidden" id="screenName" value="update_job.php">
        
        <script src="./css/code.jquery.com_jquery-3.4.1.min.js"></script>
        <script src="./css/cdn.jsdelivr.net_npm_bootstrap@5.0.0_dist_js_bootstrap.bundle.min.js"></script>
        <script src="lib/wow/wow.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>
       <script src="./js/sweetalert.js"></script>
        <script>
            $(document).ready(function() {
        navBar();
        screenInsert(); 
      
    });
    window.onscroll = function () {
            scrollFunction();
        };
        function openModal() {
            var modal = document.getElementById('myModal');
            modal.style.display = 'block';
        }

        function closeModal() {
            var modal = document.getElementById('myModal');
            modal.style.display = 'none';
        }

//////////////////////////////////////////////// Scroll function /////////////////////////////////////////////////////////

        function scrollFunction() {
            var scrollButton = document.getElementById("scrollButton");

            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                scrollButton.style.display = "block";
            } else {
                scrollButton.style.display = "none";
            }
        }
    function screenInsert(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/screenInsert.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                    if (data == 200) { 
                        render();
                    }else{
                        render();
                    }

                },

            });
    }
        function render(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/render.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                

                },

            });
    }
            function navBar(){ 
        $.ajax({
            type: "GET",
            url: "./backend/navBar/navBar.php",
            data: {  },
            success: function (data) {
                if (data == 200) {

                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="resume.php" class="nav-item nav-link">view resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';

                   
                          $("#navData").append(html);
                }else {
                    
                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="add_Cv.php" class="nav-item nav-link">Add resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';
                    
                    $("#navData").append(html); 
                }

            },

        });
    }
 
            function Update_job() {
                var updateId      = document.getElementById("updateId").value;
                var userCell      = document.getElementById("userCell").value;
                var Company_name  = document.getElementById("Company_name").value;
                var Job_title     = document.getElementById("Job_title").value;
                var jobtype       = document.getElementById("jobtype").value;
                var Timing        = document.getElementById("Timing").value; 
                var currency      = document.getElementById("currency").value; 
                var Salary_range  = document.getElementById("Salary_range").value;
                var Education     = document.getElementById("Education").value;
                var experience    = document.getElementById("experience").value;
                var Profession    = document.getElementById("Profession").value; 
                var country       = document.getElementById("country").value;
                var city          = document.getElementById("city").value;
                var datepicker    = document.getElementById("datepicker").value;

                $.ajax({
                    type: "POST",
                    url: "./backend/updateJob/updatejob.php",
                    data: {
                        "updateId"      : updateId, 
                        "userCell"      : userCell, 
                        "Company_name"  : Company_name, 
                        "Job_title"     : Job_title, 
                        "jobtype"       : jobtype, 
                        "Timing"        : Timing, 
                        "currency"      : currency, 
                        "Salary_range"  : Salary_range, 
                        "Education"     : Education, 
                        "experience"    : experience, 
                        "Profession"    : Profession, 
                        "country"       : country, 
                        "city"          : city, 
                        "datepicker"    : datepicker, 
                    },
                    success: function (data) {
                         if (data == 200) {
                           Swal.fire({
                          title: "Updated",
                          text: "Congrats your changes have been done sucessfully",
                          icon: "success",
                          confirmButtonColor: "#3085d6", 
                          confirmButtonText: "Confirm"
                        }).then((result) => {
                          if (result.isConfirmed) {
                            window.location.href = "./company_jobs.php";
                          }
                        });
                         } 
                        else {
                            Swal.fire({
                              title: "Error",
                              text: "Oops! there is some error saving your data",
                              icon: "success",
                              confirmButtonColor: "#3085d6", 
                              confirmButtonText: "Confirm"
                            }).then((result) => {
                              if (result.isConfirmed) {
                                locationReload();
                              }
                            });
                        }
                    },
                    error: function (type, obj, msg) {
                        //alert(msg);
                    },
                });
            }

            function locationReload(){
            window.location.reload();
        }
        </script> 
        
        <script src="js/main.js"></script> 
       
</body>

</html>