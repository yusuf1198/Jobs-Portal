<!DOCTYPE html>
<html lang="en">
<?php 
session_start();
include("./constants/db_config.php");
include("./constants/values.php");
   $cell = $cell; 
?>
<head>
    <meta charset="utf-8">
    <title>Green Job</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <link href="./css/first_link.css" rel="stylesheet"> 
    <link href="./css/second_link.css" rel="stylesheet">  
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet"> 
    <link href="css/bootstrap.min.css" rel="stylesheet"> 
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


     <!-- Navbar Start -->
     <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0" id="navData">
          
        </nav>
        <!-- Navbar End -->

        <!-- Header End -->
        <h1 class="text-center  wow fadeInUp" data-wow-delay="0.1s">Applied jobs</h1> 
        <!-- Header End -->
        <div class="container-xxl ">
            <div class="container">
                <!-- Jobs Start -->
                <div class="tab-content">
                    <div id="tab-1" class="tab-pane fade show p-0 active">
                     
                                <div id="showdata">
                        
                        </div>
                    </div>
                </div>
                <!-- Jobs End -->
            </div>
        </div>
    </div>


 
        <!-- Back to Top --> 
    </div>
    <input type="hidden" id="screenName" value="appliedJobs.php">
    <!-- JavaScript Libraries -->
    <script src="./css/code.jquery.com_jquery-3.4.1.min.js"></script>
    <script src="./css/cdn.jsdelivr.net_npm_bootstrap@5.0.0_dist_js_bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script> 
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="./js/sweetalert.js"></script>
    <script>
     $(document).ready(function() { 
        screenInsert();
            Applied_jobs(); 
            navBar();

            });
            function screenInsert(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/screenInsert.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                    if (data == 200) { 
                        render();
                    }else{
                        render();
                    }

                },

            });
    }
        function render(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/render.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                

                },

            });
    }
            
            function navBar(){ 
        $.ajax({
            type: "GET",
            url: "./backend/navBar/navBar.php",
            data: {  },
            success: function (data) {
                if (data == 200) {

                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="resume.php" class="nav-item nav-link">view resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';

                          $("#navData").append(html);
                }else {
                    
                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="add_Cv.php" class="nav-item nav-link">Add resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';
                    
                    $("#navData").append(html); 
                }

            },

        });
    }
 

        function Applied_jobs() {  

                $.ajax({
                    type: "POST",
                    url: "./backend/appliedJobs/appliedJobs.php",
                    data: {   },
                    success: function (data) {
                        if (data == 420) {
                             $("#showdata").append('<p align="center">No applied jobs</p>');
                         } 
                        else {
                            $.each(data, function (i, item) {
                                var j_title        = item.j_title;
                                var j_company      = item.j_company;
                                var j_status       = item.j_status;
                                var j_salary       = item.j_salary;
                                var j_strt_timing       = item.j_strt_timing;
                                var j_end_timing       = item.j_end_timing;
                                var response       = item.response;
                                var apply_before   = item.apply_before;
                                var j_address      = item.j_address;
                                var created_on     = item.created_on;
                                var remarks        = item.remarks;

                                var html = '<div class="job-item p-4 mb-4"><div class="row"><div class="col-sm-12 col-md-8 "><div class="text-start"><h6><b><b>' + j_title + '</b></b></h6><hr><p><img width="20" height="20" src="./img/building.png" alt="building"/><b>' + j_company + '</b><br></p></div></div><div class="col-sm-12 col-md-4 d-flex flex-column align-items-start align-items-md-end justify-content-center"><small class="text-truncate"><img width="20" height="20" src="./img/add-bookmark.png" alt="add-bookmark"/>' + j_status + '</small><span class="text-truncate me-0"><img width="20" height="20" src="./img/money-bag.png" alt="money-bag"/>' + j_salary + '</span><small class="text-truncate"><img width="20" height="20" src="./img/time--v1.png" alt="time--v1"/><b>Timing:</b>' + j_strt_timing + ' to ' + j_end_timing + ' </small><p><img width="20" height="20" src="./img/building.png" alt="building"/><b>Response:</b>' + response + '</p><small class="text-truncate"><img width="16" height="16" src="./img/calendar.png" alt="calendar"/><b>Apply before:</b>' + apply_before + '</small><p><img width="16" height="16" src="./img/marker.png" alt="marker" /><b><span style="font-size: 15px ;" >Location:</span>  </b>' + j_address + '<br><b><img width="16" height="16" src="./img/calendar.png" alt="calendar"/>Posted on:</b>' + created_on + '</p><small class="text-truncate"><img width="20" height="20" src="./img/time--v1.png" alt="time--v1"/><b>Remarks:</b>' + remarks + '</small></div></div></div>';

                          $("#showdata").append(html);
                          });
                    }

                    },
                    error: function (type, obj, msg) {
                        //alert(msg);
                    },
                });
            }
    </script>
    <!-- Template Javascript -->
     
    <script src="js/main.js"></script>
</body>

</html>