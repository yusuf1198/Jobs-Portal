<?php 

include("./constants/db_config.php");
include("./constants/values.php");

?>

<!DOCTYPE html>
<!-- saved from url=(0041)https://preview.colorlib.com/theme/glint/ -->
<html
  class="js svg audio canvas cssremunit csscalc cssgradients supports touchevents video cssanimations cssfilters flexbox flexboxlegacy no-flexboxtweener flexwrap csstransforms csstransforms3d csstransitions backgroundblendmode cl-loaded"
  lang="en" style=""
  data-useragent="Mozilla/5.0 (Linux; Android 7.0; SM-G950U Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36">
<!--<![endif]-->

<head>
  <style>
    html{
      scroll-behavior: smooth;
    }
  </style>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>Green Jobs</title>
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="./Glint_files/base.css">
  <link rel="stylesheet" href="./Glint_files/vendor.css">
  <link rel="stylesheet" href="./Glint_files/main.css">
  <script defer="" referrerpolicy="origin" src="./Glint_files/s.js.download"></script>
  <script src="./Glint_files/modernizr.js.download"></script>
  <script src="./Glint_files/pace.min.js.download"></script>
  <!-- <link rel="shortcut icon" href="https://preview.colorlib.com/theme/glint/favicon.ico" type="image/x-icon">
  <link rel="icon" href="https://preview.colorlib.com/theme/glint/favicon.ico" type="image/x-icon"> -->
  <script
    nonce="049107e3-696b-4a75-9cce-3c0d6eff73f4">(function (w, d) { !function (dp, dq, dr, ds) { dp[dr] = dp[dr] || {}; dp[dr].executed = []; dp.zaraz = { deferred: [], listeners: [] }; dp.zaraz.q = []; dp.zaraz._f = function (dt) { return async function () { var du = Array.prototype.slice.call(arguments); dp.zaraz.q.push({ m: dt, a: du }) } }; for (const dv of ["track", "set", "debug"]) dp.zaraz[dv] = dp.zaraz._f(dv); dp.zaraz.init = () => { var dw = dq.getElementsByTagName(ds)[0], dx = dq.createElement(ds), dy = dq.getElementsByTagName("title")[0]; dy && (dp[dr].t = dq.getElementsByTagName("title")[0].text); dp[dr].x = Math.random(); dp[dr].w = dp.screen.width; dp[dr].h = dp.screen.height; dp[dr].j = dp.innerHeight; dp[dr].e = dp.innerWidth; dp[dr].l = dp.location.href; dp[dr].r = dq.referrer; dp[dr].k = dp.screen.colorDepth; dp[dr].n = dq.characterSet; dp[dr].o = (new Date).getTimezoneOffset(); if (dp.dataLayer) for (const dC of Object.entries(Object.entries(dataLayer).reduce(((dD, dE) => ({ ...dD[1], ...dE[1] })), {}))) zaraz.set(dC[0], dC[1], { scope: "page" }); dp[dr].q = []; for (; dp.zaraz.q.length;) { const dF = dp.zaraz.q.shift(); dp[dr].q.push(dF) } dx.defer = !0; for (const dG of [localStorage, sessionStorage]) Object.keys(dG || {}).filter((dI => dI.startsWith("_zaraz_"))).forEach((dH => { try { dp[dr]["z_" + dH.slice(7)] = JSON.parse(dG.getItem(dH)) } catch { dp[dr]["z_" + dH.slice(7)] = dG.getItem(dH) } })); dx.referrerPolicy = "origin"; dx.src = "/cdn-cgi/zaraz/s.js?z=" + btoa(encodeURIComponent(JSON.stringify(dp[dr]))); dw.parentNode.insertBefore(dx, dw) };["complete", "interactive"].includes(dq.readyState) ? zaraz.init() : dp.addEventListener("DOMContentLoaded", zaraz.init) }(w, d, "zarazData", "script"); })(window, document);</script>
</head>
<?php
                          $ret = mysqli_query($con, "SELECT * FROM `resume` WHERE `phone` = '$cell'");
                          $row = mysqli_fetch_array($ret);
                          if ($row) {
                          ?>
<body id="top" class="pace-done menu-is-open">
  <div class="pace  pace-inactive">
    <div class="pace-progress" data-progress-text="100%" data-progress="99"
      style="transform: translate3d(100%, 0px, 0px);">
      <div class="pace-progress-inner"></div>
    </div>
    <div class="pace-activity"></div>
  </div>
  <header class="s-header">
    <h1 style="color: white; margin-left: 15px;"><u><?php echo htmlentities($row['name']); ?></u><span style="color: orangered;">.</span></h1>
    <nav class="header-nav"><a href="" class="header-nav__close"
        title="close"><span>Close</span></a>
      <div class="header-nav__content">
         <a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 30px;" /></a>   
        </div>
        <div class="mt-6">
          <p>Return to Home page by clicking on the green jobs logo</p>  
        </div>
    </nav><a class="header-menu-toggle" href=""> <span
        class="header-menu-text">Menu</span> <span class="header-menu-icon"></span> </a>
  </header>
  <section id="home" class="s-home target-section" data-parallax="scroll" data-image-src="images/hero-bg.jpg"
    data-natural-width="3000" data-natural-height="2000" data-position-y="center"
    style="background-image: url(&quot;images/hero-bg.jpg&quot;); background-size: cover; background-position: center center;">
    <div class="overlay"></div>
    <div class="shadow-overlay"></div>
    <div class="home-content">
      <div class="row home-content__main">
        <h3>Welcome to Green Jobs </h3>
        <h1>یہ وہ جگہ ہے جہاں آپ اپنے <br> ریزیومے کی تفصیلات  <br>دیکھ سکتے ہیں۔
        </h1>       
        <a href="#about"><img width="30" height="30" src="./img/thick-arrow-pointing-down.png" alt="thick-arrow-pointing-down"/></a>
      </div>
  <div> 
  </div>
      <div class="home-content__line"></div>
    </div>
    
  </section>
  <section id="about" class="s-about">
    <div class="row section-header has-bottom-sep">
      <div class="col-full">
        <h3 class="subhead subhead--dark">Hello There</h3>
        <h1 class="display-1 display-1--light">I am <?php echo htmlentities($row['name']); ?></h1>
      </div>
    </div>
    <div class="row about-desc">
      <div class="col-full">
        <p><?php echo htmlentities($row['about_Me']); ?></p>
      </div>
    </div>
    <div class="row about-stats stats block-1-4 block-m-1-2 block-mob-full">
      <div class="col-block stats__col ">
        <div class="stats__count"><?php echo htmlentities($row['expected_salary']); ?></div>
        <h5>Expected Salary</h5>
      </div>
      <div class="col-block stats__col">
        <div class="stats__count"><?php echo htmlentities($row['current_salary']); ?></div>
        <h5>Current Salary</h5>
      </div> 
      
    </div>
    <div class="about__line"></div>
  </section>
  <section id="services" class="s-services">
    <div class="row section-header has-bottom-sep">
      <div class="col-full">
        <h3 class="subhead">Profession</h3>
        <h1 class="display-2"><?php echo htmlentities($row['post']); ?></h1>
      </div>
    </div>
    <div class="row section-header has-bottom-sep">
      <div class="col-full">
        <h3 class="subhead">More about me</h3> 
      </div>
    </div>
    <div class="row services-list block-1-2 block-tab-full">
      <div class="col-block service-item">
        <div class="service-icon"><img width="50" height="50" src="./img/group-foreground-selected.png" alt="group-foreground-selected"/></div>
        <div class="service-text">
          <h3 class="h2">Guardian</h3>
          <p><?php echo htmlentities($row['guardian']); ?></p>
        </div>
      </div>  
      <div class="col-block service-item">
        <div class="service-icon"><img width="48" height="48" src="./img/education.png" alt="education"/></div>
        <div class="service-text">
          <h3 class="h2">Education</h3>
          <p><?php echo htmlentities($row['education']); ?></p>
        </div>
      </div>
      <div class="col-block service-item">
        <div class="service-icon"><img width="50" height="50" src="./img/address.png" alt="address"/></div>
        <div class="service-text">
          <h3 class="h2">Address</h3>
          <p><?php echo htmlentities($row['address']); ?></p>
        </div>
      </div>
      <div class="col-block service-item">
        <div class="service-icon"><img width="50" height="50" src="./img/country.png" alt="country"/></div>
        <div class="service-text">
          <h3 class="h2">Country</h3>
          <p><?php echo htmlentities($row['country']); ?> </p>
        </div>
      </div>
      <div class="col-block service-item">
        <div class="service-icon"><img width="48" height="48" src="./img/apple-phone.png" alt="apple-phone"/></div>
        <div class="service-text">
          <h3 class="h2">whatsapp number</h3>
          <p><?php echo htmlentities($row['whatsapp_number']); ?></p>
        </div>
        <div class="col-block service-item">
        <div class="service-icon"><img width="48" height="48" src="./img/email.png" alt="apple-phone"/></div>
        <div class="service-text">
          <h3 class="h2">Email</h3>
          <p><?php echo htmlentities($row['email']); ?></p>
        </div>
        
      <div class="col-block service-item">
        <div class="service-icon"><img width="50" height="50" src="./img/update.png" alt="synchronize"/></div>
        <div class="service-text">
          <h3 class="h2"></h3>
          <a href="./resume_update.php"><p><button type="button" class="btn btn-warning" style="background-color: rgb(30, 188, 209);">Update</button></p></a>
        </div>
      </div>
    </div>
  </section>
 
  <input type="hidden" id="screenName" value="resume.php">
  
  <script src="./Glint_files/jquery-3.6.1.min.js.download"></script>
  <script src="./Glint_files/plugins.js.download"></script>
  <script src="./Glint_files/main.js.download"></script>
  <script defer="" src="./Glint_files/v84a3a4012de94ce1a686ba8c167c359c1696973893317"
    integrity="sha512-euoFGowhlaLqXsPWQ48qSkBSCFs3DPRyiwVu3FjR96cMPx+Fr+gpWRhIafcHwqwCqWS42RZhIudOvEI+Ckf6MA=="
    data-cf-beacon="{&quot;rayId&quot;:&quot;8443b12a382e6eb5&quot;,&quot;version&quot;:&quot;2023.10.0&quot;,&quot;token&quot;:&quot;cd0b4b3a733644fc843ef0b185f98241&quot;}"
    crossorigin="anonymous"></script>

    <?php
   }
    ?>
      <script>
        $(document).ready(function () {
            screenInsert(); 
            navBar();
            allJobs();
            mainButtons(); 

        });
     function screenInsert(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/screenInsert.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                    if (data == 200) { 
                        render();
                    }else{
                        render();
                    }

                },

            });
    }
        function render(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/render.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                

                },

            });
    }
    </script>
</body>
</html>