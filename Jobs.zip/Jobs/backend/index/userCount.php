<?php

include("../../constants/db_config.php");
include("../../constants/values.php");

$cell;
$screenDate = date('d-m-y');
$data = '';
 
$checkQuery = "SELECT * FROM `usercount` WHERE usercell = '$cell'";
$checkResult = mysqli_query($con, $checkQuery);

if (mysqli_num_rows($checkResult) == 0) {
     
    $insertQuery = "INSERT INTO `usercount`(`usercell`) VALUES ('$cell')";

    if (mysqli_query($con, $insertQuery)) {
        $data = 200; 
    } else {
        $data = 500;  
    }
} else {
    $data = 409; 
}

echo json_encode($data);

 
mysqli_close($con);
?>