<?php
include("../../constants/db_config.php");
include("../../constants/values.php"); 

$screenName =             $_GET['screenName'];
$accessDate =             date("d-m-y");

 
 $ret = ( "SELECT * FROM `screens` WHERE `name` = '$screenName'"); 
$check = mysqli_query($con, $ret);
    while ($row = mysqli_fetch_array($check)) {
        $count = ($row['count']);
       $final = $count + 1 ;
    }

 $query = "UPDATE `screens` SET `date`='$accessDate',`count`='$final' WHERE `name` = '$screenName'";

if(mysqli_query($con, $query)){ 
    $data = '200';
}
else{
    $data = '500';
}
echo json_encode($data);
?>