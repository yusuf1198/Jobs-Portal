<?php

include("../../constants/db_config.php");
include("../../constants/values.php");

$screenName = $_GET['screenName'];
$screenDate = date('d-m-y');
$data = '';
 
$checkQuery = "SELECT * FROM `screens` WHERE `name` = '$screenName'";
$checkResult = mysqli_query($con, $checkQuery);

if (mysqli_num_rows($checkResult) == 0) {
     
    $insertQuery = "INSERT INTO `screens`(`name`, `date`, `count`) VALUES ('$screenName','$screenDate','0')";

    if (mysqli_query($con, $insertQuery)) {
        $data = 200; 
    } else {
        $data = 500;  
    }
} else {
    $data = 409; 
}

echo json_encode($data);

 
mysqli_close($con);
?>
