<?php 
    session_start();
    include("../../constants/db_config.php");
    include("../../constants/values.php"); 

    $button = '';
    $query = mysqli_query($con, "SELECT * FROM `resume` WHERE `phone` = '$cell'");
    while ($row = mysqli_fetch_array($query)) {
         $cv_id  =             $row['cv_id']; 
    if (mysqli_num_rows($query) > 0) {   
        $button = 150;
    } else { 
        $button = 170;
    } 
    }
    $ret = mysqli_query($con, "SELECT * FROM `jobs`");
    while ($row = mysqli_fetch_array($ret)) {

        $title =             $row['title'];
        $j_id =             $row['id'];
        $company =           $row['company'];
        $status =            $row['status'];
        $start_time =            $row['start_time'];
        $end_time =            $row['end_time'];
        $Salary =            $row['Salary'];
        $Apply_before =      $row['Apply_before'];
        $adress =            $row['adress'];
        $created_on =        $row['created_on'];
        
        $data[] = array(
            'j_id'          => $j_id,  
            'title'          => $title,  
            'company'        => $company,  
            'status'         => $status,  
            'start_time'         => $start_time,  
            'end_time'         => $end_time,  
            'Salary'         => $Salary,  
            'Apply_before'   => $Apply_before,  
            'adress'         => $adress,  
            'created_on'     => $created_on,  
            'button'         => $button,
            'cv_id'         => $cv_id
        );
    }
        
            

                    header('content-type: application/json');
                    echo json_encode($data); 
             ?>





 

 