<?php
 include("../../constants/db_config.php"); 
 include("../../constants/values.php");
  
 $ret = "SELECT * FROM `resume` where `phone` = '$cell'";
 $conn = mysqli_query($con,$ret);
  $row = mysqli_fetch_array($conn); 
   if($row) { 

     $cv_id  = (($row['cv_id']));
     $name = (($row['name']));
     $guardian = (($row['guardian']));
     $post = (($row['post']));
     $phone = (($row['phone']));
     $whatsapp_number = (($row['whatsapp_number']));
     $email = (($row['email']));
     $address = (($row['address']));
     $country = (($row['country']));
     $about_Me = (($row['about_Me']));
     $work_Exp = (($row['work_Exp']));
     $education = (($row['education']));
     $languages = (($row['languages']));
     $expected_salary = (($row['expected_salary']));
     $current_salary = (($row['current_salary']));
     $city_of_interest = (($row['city_of_interest']));
     $projects = (($row['projects']));
   }
 $data ='';
  $cvSubmission = "INSERT INTO `apply_request`(`cv_id`, `name`, `guardian`, `post`, `phone`, `whatsapp_number`, `email`, `address`, `country`, `about_Me`, `work_Exp`, `education`, `languages`, `expected_salary`, `current_salary`, `city_of_interest`, `projects`) VALUES ('$cv_id','$name','$guardian','$post','$phone','$whatsapp_number','$email','$address','$country','$about_Me','$work_Exp','$education','$languages','$expected_salary','$current_salary','$city_of_interest','$projects')";

if(mysqli_query($con, $cvSubmission)) { 

$data = 200;

 } else {
    $data = 420;
 }

 header('content-type: application/json');
 echo json_encode($data);
?>