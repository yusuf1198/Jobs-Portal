<?php
include("../../constants/db_config.php");
include("../../constants/values.php");

$resultId = $_GET['resultId'];

// Fetch a single job entry corresponding to $ResultId
$result = mysqli_query($con, "SELECT * FROM `req_jobs` WHERE j_id = $resultId LIMIT 1");
$row = mysqli_fetch_assoc($result);
$datadiv = array(); // Initialize an array to store the job entry data

if ($row) {
    $j_title =        $row['j_title']; 
    $j_salary =        $row['j_salary']; 
    $apply_before =        $row['apply_before']; 
    $j_address =        $row['j_address']; 
    $created_on =        $row['created_on']; 
    $j_status =        $row['j_status']; 
    $j_company =        $row['j_company'];   
    $j_timing =        $row['j_timing'];   

    $data[] = array(
        'j_title'      => $j_title,   
        'j_salary'      => $j_salary,   
        'apply_before'      => $apply_before,   
        'j_address'      => $j_address,   
        'created_on'      => $created_on,   
        'j_status'      => $j_status,  
        'j_company'      => $j_company,   
        'j_timing'      => $j_timing,   
    );
}


// Encode the job entry data into JSON format
header('content-type: application/json');
echo json_encode($data);
 
?>