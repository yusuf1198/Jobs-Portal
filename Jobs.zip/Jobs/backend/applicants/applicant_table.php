<?php
include("../../constants/db_config.php");
include("../../constants/values.php");

$resultId = $_GET['resultId'];  
$data = array(); // Initialize an array to store all rows

$ret = mysqli_query($con, "SELECT * FROM `req_jobs` WHERE j_id = '$resultId'"); 

if (mysqli_num_rows($ret) > 0) {
    while ($row = mysqli_fetch_array($ret)) {
        // Store each row in the data array
        $data[] = array(
            'u_name'     => $row['u_name'],
            'u_phone' => $row['u_phone'],
            'u_post'   => $row['u_post'],
            'expected_salary'    => $row['expected_salary'],
            'remarks'    => $row['remarks'],
            'id'         => $row['id']
        );
    }
}

// Encode the entire data array into JSON format
header('content-type: application/json');
echo json_encode($data);
 
?>