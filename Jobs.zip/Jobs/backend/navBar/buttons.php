<?php
include("../../constants/db_config.php");
include("../../constants/values.php");

$ret = mysqli_query($con, "SELECT * FROM `resume` where `phone` = '$cell'");
$row = mysqli_fetch_array($ret); 
$data = '';
if($row) {
$data = 200;
}else{
    $data = 250;
}
header('content-type: application/json');
echo json_encode($data);

?>