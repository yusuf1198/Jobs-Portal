<?php
include("../../constants/db_config.php");
include("../../constants/values.php");

		$ret = mysqli_query($con, "SELECT * FROM `req_jobs` where `u_phone` = '$cell'");
     
		while ($row = mysqli_fetch_array($ret)) 
		{
            $j_title =        $row['j_title']; 
            $j_company =      $row['j_company']; 
            $j_status =       $row['j_status']; 
            $j_salary =       $row['j_salary']; 
            $j_strt_timing =       $row['j_strt_timing']; 
            $j_end_timing =       $row['j_end_timing']; 
            $response =       $row['response']; 
            $apply_before =   $row['apply_before']; 
            $j_address =      $row['j_address']; 
            $created_on =     $row['created_on']; 
            $remarks =        $row['remarks']; 

            $data[] = array(
                'j_title'      => $j_title,  
                'j_company'    => $j_company,  
                'j_status'     => $j_status,  
                'j_salary'     => $j_salary,  
                'j_strt_timing'     => $j_strt_timing,  
                'j_end_timing'     => $j_end_timing,  
                'response'     => $response,  
                'apply_before' => $apply_before,  
                'j_address'    => $j_address,  
                'created_on'   => $created_on,  
                'remarks'      => $remarks
            );
            
        }
        
        

        header('content-type: application/json');
        echo json_encode($data);
 ?> 