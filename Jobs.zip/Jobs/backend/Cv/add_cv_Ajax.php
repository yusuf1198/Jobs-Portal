<?php
 include("../../constants/db_config.php"); 
 include("../../constants/values.php");

    $cell = $cell;    
    $name = $_POST['name']; 
    $guardian = $_POST['guardian']; 
    $whatsapp = $_POST['whatsapp']; 
    $Profession = $_POST['Profession']; 
    $email = $_POST['email']; 
    $Address = $_POST['Address']; 
    $About_Me = $_POST['About_Me']; 
    $Work_Experiance = $_POST['Work_Experiance']; 
    $credentials = $_POST['credentials']; 
    $Languages = $_POST['Languages']; 
    $Expected_salary = $_POST['Expected_salary']; 
    $Current_salary = $_POST['Current_salary']; 
    $interest = $_POST['interest']; 
    $country = $_POST['country']; 
    $Works = $_POST['Works']; 
    $Date_time = date("d-m-y"); // Change date format if required

    // if (['example-select']) {
    //     $Skills = $_POST['example-select'];
    //     $skillsString = implode(",", $Skills); // Convert array to string
        
        // Database query to insert data along with the selected skills
          $query = "INSERT INTO `resume`( `name`, `guardian`, `post`, `phone`, `whatsapp_number`, `email`, `address`, `country`, `about_Me`,`work_Exp`, `education`, `languages`, `expected_salary`, `current_salary`, `city_of_interest`, `projects`, `created_on`, `updated_on`, `deleted_on`) VALUES ('$name','$guardian','$Profession','$cell','$whatsapp','$email','$Address','$country','$About_Me','$Work_Experiance','$credentials','$Languages','$Expected_salary','$Current_salary','$interest','$Works','$Date_time','$Date_time','0')";
         
        if(mysqli_query($con, $query)) {  
            // Rest of your code for successful insertion
            $last_id = mysqli_insert_id($con); 

            $directory = "../../Data/";
            if (!is_dir($directory)) {
            mkdir($directory);
            }	
            $directory = "../../Data/resume/";
            if (!is_dir($directory)) {
            mkdir($directory);
            } 
            
            $fileName = "../../Data/resume/$cell.txt";
            $myFile = fopen($fileName, "w") or die("Unable to open file"); 
            $txt = $name . "~@~" . $guardian . "~@~" . $whatsapp . "~@~" . $cell . "~@~" . $email . "~@~" . $Address . "~@~" . $About_Me . "~@~" . $Work_Experiance ."~@~" . $credentials ."~@~" . $Languages ."~@~" . $Expected_salary ."~@~" . $Current_salary ."~@~" . $interest ."~@~" . $country ."~@~" . $Works ."~@~" . $Date_time ."~@~" . 0 . "\n";
            fwrite($myFile, $txt);
            fclose($myFile); 
            $Data = 200;
        } else {
            $Data = 420;
        } 

        header('content-type: application/json');
        echo json_encode($Data);
    
?>