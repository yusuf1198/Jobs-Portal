<?php

date_default_timezone_set('asia/karachi');
include("../../constants/db_config.php");
include("../../constants/values.php"); 
  
     $updateId        = $_POST['updateId'];
     $userCell        = $_POST['userCell'];
     $Experience        = $_POST['experience'];
     $Job_Status        = $_POST['jobtype']; 
     $Country           = $_POST['country']; 
     $City              = $_POST['city']; 
     $currency          = $_POST['currency']; 
     $Salary_range      = $_POST['Salary_range'];  
     $Education         = $_POST['Education']; 
     $Timing            = $_POST['Timing']; 
     $Job_title         = $_POST['Job_title']; 
     $Apply_before      = $_POST['datepicker']; 
     $Company_name      = $_POST['Company_name'];    
     $Date_time = date("d-m-y");  

       $query="UPDATE `jobs` SET `title`='$Job_title',`company`='$Company_name',`Salary`='$Salary_range',`experience`='$Experience',`Apply_before`='$Apply_before',`education`='$Education',`adress`='$City',`timing`='$Timing',`status`='$Job_Status',`created_on`='$Date_time',`updated_on`='$Date_time',`deleted_on`='$Date_time',`cell`='$userCell' WHERE `id` ='$updateId'";
         

       $data = '';
     if(mysqli_query($con, $query))
     {  
         $data = 200;

     }
     else
     {
         $data = 420;
     }  
     echo json_encode($data);
?>