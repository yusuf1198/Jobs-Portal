<?php
echo "something";
die();
date_default_timezone_set('Asia/Karachi');
include("../../constants/db_config.php");
include("../../constants/values.php");
 
    $userCell = $_POST['userCell']; 
    $name = $_POST['name']; 
    $guardian = $_POST['guardian']; 
    $whatsapp = $_POST['whatsapp']; 
    $Profession = $_POST['Profession']; 
    $email = $_POST['email']; 
    $Address = $_POST['Address']; 
    $About_Me = $_POST['About_Me']; 
    $Work_Experiance = $_POST['Work_Experiance']; 
    $credentials = $_POST['credentials']; 
    $Languages = $_POST['Languages']; 
    $Expected_salary = $_POST['Expected_salary']; 
    $Current_salary = $_POST['Current_salary']; 
    $interest = $_POST['interest']; 
    $country = $_POST['country']; 
    $Works = $_POST['Works']; 
    $Date_time = date("Y-m-d H:i:s"); 
    $data = '';
        
         $query = "UPDATE `resume` SET `name`='$name',`guardian`='$guardian',`post`='$Profession',`phone`='$userCell',`whatsapp_number`='$whatsapp',`email`='$email',`address`='$Address',`country`='$country',`about_Me`='$About_Me',`work_Exp`='$Work_Experiance',`education`='$',`languages`='$Languages',`expected_salary`='$Expected_salary',`current_salary`='$Current_salary',`city_of_interest`='$interest',`projects`='$Works',`created_on`='$Date_time',`updated_on`='$Date_time',`deleted_on`='0' WHERE `phone` = '$userCell'";
        
        if(mysqli_query($con, $query)) { 
             $data = 200;
        } else {
            $data = 420;
        } 
        header('content-type: application/json');
        echo json_encode($data);
    

?>