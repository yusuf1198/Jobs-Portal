<?php
 date_default_timezone_set('Asia/Karachi');
 include("../../constants/db_config.php");
 include("../../constants/values.php");

    $cell               = $cell;   
    $name               = $_GET['name']; 
    $guardian           = $_GET['guardian']; 
    $whatsapp           = $_GET['whatsapp']; 
    $email              = $_GET['email']; 
    $Address            = $_GET['Address']; 
    $Profession         = $_GET['Profession']; 
    $About_Me           = $_GET['About_Me']; 
    $Work_Experiance    = $_GET['Work_Experiance']; 
    $credentials        = $_GET['credentials']; 
    $created_on         = $_GET['created_on']; 
    $Languages          = $_GET['Languages']; 
    $currency           = $_GET['currency']; 
    $currency2          = $_GET['currency2']; 
    $interest           = $_GET['interest']; 
    $country            = $_GET['country']; 
    $Works              = $_GET['Works'];  
    $Current_salary              = $_GET['Current_salary']; 
    $Expected_salary              = $_GET['Expected_salary']; 
    
     $salary = $Current_salary . $currency2; 
     $salary2 = $Expected_salary . $currency; 
    $Date_time = date("Y-m-d");  
 
         $data='';
      echo   $query = "UPDATE `resume` SET `name`='$name',`guardian`='$guardian',`post`='$Profession',`whatsapp_number`='$whatsapp',`email`='$email',`address`='$Address',`country`='$country',`about_Me`='$About_Me',`work_Exp`='$Work_Experiance',`education`='$credentials',`languages`='$Languages',`expected_salary`='$salary2',`current_salary`='$salary',`city_of_interest`='$interest',`projects`='$Works',`created_on`='$created_on',`updated_on`='$Date_time',`deleted_on`='0' WHERE `phone` = '$cell' ";
        
        if(mysqli_query($con, $query)) {  
             $data = 200;
        } else {
            $data = 420;
        } 
        header('content-type: application/json');
        echo json_encode($data);
    
?>