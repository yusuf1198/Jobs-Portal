<?php
include("../../constants/db_config.php");
include("../../constants/values.php"); 
    $ret = mysqli_query($con, "SELECT * FROM `jobs` where cell = '$cell'");
        while ($row = mysqli_fetch_array($ret)) {
 
           $created_on =      $row['created_on'];
           $adress =          $row['adress']; 
           $Apply_before =    $row['Apply_before'];
           $Salary =          $row['Salary'];
           $j_strt_timing =          $row['start_time'];
           $j_end_timing =          $row['end_time'];
           $id  =             $row['id'];
           $status  =             $row['status'];
           $company =         (strtoupper($row['company'])); 
           $title =           (strtoupper($row['title'])); 

           $data[] = array(
            'created_on'   => $created_on, 
            'adress'       => $adress, 
            'Apply_before' => $Apply_before, 
            'Salary'       => $Salary, 
            'j_strt_timing'       => $j_strt_timing, 
            'j_end_timing'       => $j_end_timing, 
            'company'      => $company, 
            'id'           => $id, 
            'status'           => $status, 
            'title'        => $title
        );

        }

      
        header('content-type: application/json');
        echo json_encode($data);

?>