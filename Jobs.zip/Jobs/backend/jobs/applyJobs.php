<?php

include("../../constants/db_config.php");
include("../../constants/values.php");

$title       = $_POST['title']; 
$company = $_POST['company']; 
$status = $_POST['status']; 
$start_time = $_POST['start_time']; 
$end_time = $_POST['end_time']; 
$Salary = $_POST['Salary']; 
$Apply_before = $_POST['Apply_before']; 
$adress = $_POST['adress']; 
$created_on = $_POST['created_on']; 
$jobID = $_POST['jobID']; 
$response = $_POST['response']; 
$experience = $_POST['experience']; 
$data = '';
 $form = mysqli_query($con, "SELECT * FROM `resume` where phone = '$cell'");
 while ($row = mysqli_fetch_array($form)) {

 
 $name              = $row['name']; 
 $guardian          = $row['guardian']; 
 $post              = $row['post']; 
 $phone             = $row['phone']; 
 $whatsapp_number   = $row['whatsapp_number']; 
 $address           = $row['address']; 
 $email             = $row['email'];  
 $about_Me          = $row['about_Me']; 
 $work_Exp          = $row['work_Exp']; 
 $education         = $row['education']; 
 $languages         = $row['languages']; 
 $expected_salary   = $row['expected_salary']; 
 $current_salary    = $row['current_salary']; 
 $city_of_interest  = $row['city_of_interest']; 
 $projects          = $row['projects'];  
 }
 $Date_time = date("d-m-y"); 
 if (!empty($response)) {
   $query="INSERT INTO `req_jobs`(`j_id`, `j_title`, `j_address`, `j_company`, `j_status`, `j_strt_timing`, `j_end_timing`, `apply_before`, `j_salary`, `j_created_on`, `response`, `u_name`, `u_guardian`, `u_post`, `u_phone`, `u_whatsapp`, `u_email`, `about_me`, `work_exp`, `u_education`, `languages`, `expected_salary`, `current_salary`, `city_of_interest`, `project`, `created_on`, `updated_on`, `deleted_on`) VALUES ('$jobID','$title','$adress','$company','$status','$start_time','$end_time','$Apply_before','$Salary','$created_on','$response','$name','$guardian','$post','$phone','$whatsapp_number','$email','$about_Me','$work_Exp','$education','$languages','$expected_salary','$current_salary','$city_of_interest','$projects','$Date_time','$Date_time','0')";


  if(mysqli_query($con, $query)){ 

$last_id = mysqli_insert_id($con);

$directory = "../../Data/";
if (!is_dir($directory)) {
    mkdir($directory);
}	
$directory = "../../Data/Applicants/";
if (!is_dir($directory)) {
mkdir($directory);
}

$fileName = "../../Data/Applicants/$phone.txt";
$myFile = fopen($fileName, "a") or die("Unable to open file");

$txt = $jobID. "~@~" .$title . "~@~" . $address . "~@~" . $company . "~@~" . $status. "~@~" . $Apply_before . "~@~" . $Salary . "~@~" . $response . "~@~" . $name . "~@~" . $guardian . "~@~" . $post . "~@~" . $phone . "~@~" . $whatsapp_number . "~@~" . $email . "~@~" . $about_Me . "~@~" . $work_Exp . "~@~" . $education . "~@~" . $languages .  "~@~" . $expected_salary . "~@~" . $current_salary . "~@~" . $city_of_interest . "~@~" . $projects . "~@~" . $Date_time . "~@~" . $Date_time ."\n";

fwrite($myFile, $txt);
fclose($myFile);
$data = 200;
}
else{
$data = 420;
}
 }else{
  $data = 500;
 }
 
 

header('content-type: application/json');
echo json_encode($data);


?>