<?php   

 date_default_timezone_set('asia/karachi'); 
    include("./constants/db_config.php");
    include("./constants/values.php");   
    $jobID = htmlspecialchars($_GET['jobid']); 
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Green Job</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <link href="./css/first_link.css" rel="stylesheet"> 
    <link href="./css/second_link.css" rel="stylesheet">  
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet"> 
    <link href="css/bootstrap.min.css" rel="stylesheet"> 
    <link href="css/style.css" rel="stylesheet">
    <style>
    
  @import url('./css/fonts_links.css'); 

.form-label {
    font-family: 'Noto Nastaliq Urdu', serif;
}
</style>
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

     <!-- Navbar Start -->
     <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0" id="navData">
          
        </nav>
        <!-- Navbar End -->
        
        <!-- Header End -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="tab-content">
                    <div id="tab-1" class="tab-pane fade show p-0 active">
                        <?php
                             $ret = mysqli_query($con, "SELECT * FROM `jobs` where id= $jobID");
                             while ($row = mysqli_fetch_array($ret)) {
                            ?>
                                <input type="hidden" id="title" value = "<?php echo (strtoupper($row['title'])); ?>"> 
                                <input type="hidden" id="company" value = "<?php echo (strtoupper($row['company'])); ?>"> 
                                <input type="hidden" id="status" value = "<?php echo (strtoupper($row['status'])); ?>"> 
                                <input type="hidden" id="start_time" value = "<?php echo (strtoupper($row['start_time'])); ?>"> 
                                <input type="hidden" id="end_time" value = "<?php echo (strtoupper($row['end_time'])); ?>"> 
                                <input type="hidden" id="Salary" value = "<?php echo (strtoupper($row['Salary'])); ?>"> 
                                <input type="hidden" id="Apply_before" value = "<?php echo (strtoupper($row['Apply_before'])); ?>"> 
                                <input type="hidden" id="adress" value = "<?php echo (strtoupper($row['adress'])); ?>"> 
                                <input type="hidden" id="created_on" value = "<?php echo (strtoupper($row['created_on'])); ?>"> 
                                <input type="hidden" id="experience" value = "<?php echo (strtoupper($row['experience'])); ?>"> 
                                <input type="hidden" id="jobID" value = "<?php echo $jobID; ?>"> 

                        <div class="job-item p-4 mb-4">
                            <div class="row">
                                <div class="col-sm-12 col-md-8 ">
                                    <div class="text-start"> 
                                        <h6><b>
                                        <b><?php echo htmlentities(strtoupper($row['title'])); ?></b>
                                            </b></h6>
                                        <hr> <!-- Line after the title -->
                                        <p><img width="20" height="20" src="./img/building.png" alt="building"/>
                                           <b>  <?php echo htmlentities(strtoupper($row['company'])); ?></b> <br>
                                        </p>
                                    </div>
                                </div>  
                                <span class="text-truncate me-0" id="status"><img width="20" height="20" src="./img/add-bookmark.png" alt="add-bookmark"/>

                                        <?php echo htmlentities($row['status']);?>
                                    </span>
                                <div class="col-sm-12 col-md-4 d-flex flex-column align-items-start align-items-md-end justify-content-center"> 
                                    <span class="text-truncate me-3"><img width="20" height="20" src="./img/time--v1.png" alt="time--v1"/>
                                        <?php echo htmlentities($row['start_time']);?> to <?php echo htmlentities($row['end_time']);?>  
                                    </span>
                                    <span class="text-truncate me-0"><img width="20" height="20" src="./img/money-bag.png" alt="money-bag"/>
                                        <?php echo htmlentities($row['Salary']);?>
                                    </span> 
                                    <small class="text-truncate"><img width="18" height="18" src="./img/calendar.png" alt="calendar"/>
                                        <b>Apply Before:</b>
                                        <?php echo htmlentities($row['Apply_before']);?>
                                    </small>
                                    <p><img width="16" height="16" src="./img/marker.png" alt="marker" />
                                        <b><span style="font-size: 15px ;" >Location:</span> </b><?php echo htmlentities($row['adress']); ?>
                                   <br>
                                        <b><img width="18" height="18" src="./img/calendar.png" alt="calendar"/>Posted on:</b>
                                        <?php echo htmlentities($row['created_on']);?>
                                    </p>   
                                    <div class="col-md-12" style="width: 100%;">
                                        <label  class="form-label">Response جواب</label>
                                        <textarea id="response" name="Response" required type="text"  placeholder="آجر کو بتائیں کہ آپ اس کام کے لیے کس طرح بہترین ہیں۔" class="form-control form-label col-md-12"></textarea>
                                    </div> 
                                <button value="submit" name="submit" class="btn btn-primary btn-hidden btn-lg collapsed mt-3 " onclick ="applyJob()">Apply</button>
                                </div> 
                            </div>
                        </div>
                    
                        <?php 
                            } 
                        ?>
                    </div>
                </div>
                <!-- Jobs End -->
            </div>
        </div>
    </div>

        
 
        <!-- Back to Top --> 
    </div>
    <input type="hidden" id="screenName" value="apply_job.php">
    <!-- JavaScript Libraries -->
 <!-- JavaScript Libraries -->
 <script src="./css/code.jquery.com_jquery-3.4.1.min.js"></script>
    <script src="./css/cdn.jsdelivr.net_npm_bootstrap@5.0.0_dist_js_bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script> 
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
   <script src="./js/sweetalert.js"></script>
    <script>
        $(document).ready(function () {
            screenInsert();
            navBar();
        });
        function screenInsert(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/screenInsert.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                    if (data == 200) { 
                        render();
                    }else{
                        render();
                    }

                },

            });
    }
        function render(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/render.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                

                },

            });
    }
            
        function navBar(){ 
        $.ajax({
            type: "GET",
            url: "./backend/navBar/navBar.php",
            data: {  },
            success: function (data) {
                if (data == 200) {

                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="resume.php" class="nav-item nav-link">view resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';

                   
                          $("#navData").append(html);
                }else {
                    
                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="add_Cv.php" class="nav-item nav-link">Add resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';
                    
                    $("#navData").append(html); 
                }

            },

        });
    }
        function applyJob() {
          
            var title = document.getElementById("title").value;
            var company = document.getElementById("company").value;
            var status = document.getElementById("status").value;
            var start_time = document.getElementById("start_time").value;
            var end_time = document.getElementById("end_time").value;
            var Salary = document.getElementById("Salary").value;
            var Apply_before = document.getElementById("Apply_before").value;
            var adress = document.getElementById("adress").value;
            var created_on = document.getElementById("created_on").value; 
            var jobID = document.getElementById("jobID").value; 
            var response = document.getElementById("response").value; 
            var experience = document.getElementById("experience").value; 
            $.ajax({
                type: "POST",
                url: "./backend/jobs/applyJobs.php",
                data: {
                    "title": title,
                    "company": company,
                    "status": status,
                    "start_time": start_time,
                    "end_time": end_time,
                    "Salary": Salary,
                    "Apply_before": Apply_before,
                    "adress": adress,
                    "created_on": created_on,
                    "experience": experience,
                    "response": response,
                    "jobID": jobID
                },
                success: function (data) {
                    if (data == 200) {
                           Swal.fire({
                          title: "Updated",
                          text: "Job request added sucessfully",
                          icon: "success",
                          confirmButtonColor: "#3085d6", 
                          confirmButtonText: "Ok"
                        }).then((result) => {
                          if (result.isConfirmed) {
                            locationReload();
                          }
                        });
                         } 
                    else {
                        Swal.fire({
                          title: "We are sorry!",
                          text: "There is some problem completing your request",
                          icon: "warning"
                        });
                    }


                },
                error: function (type, obj, msg) {
                    //alert(msg);
                },
            });
        }
        function locationReload(){
            window.location.reload();
        }
        </script>
    <!-- Template Javascript -->
 
</body>

</html>