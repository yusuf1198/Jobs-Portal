<?php  
date_default_timezone_set('Asia/Karachi');
include("./constants/db_config.php");
include("./constants/values.php");


?>
 
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <title>Green Jobs</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">


    <link href="./css/first_link.css" rel="stylesheet">
    <link href="./css/second_link.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
    
  @import url('./css/fonts_links.css'); 

.form-label {
    font-family: 'Noto Nastaliq Urdu', serif;
} 
        @import url('./css/fonts_links.css');

        .form-label {
            font-family: 'Noto Nastaliq Urdu', serif;
        }
        #scrollButton {
            display: none;
            height: 70px;
            width: 70px;
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 10px; 
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.7);
        }

        .modal-content {
            margin: 15% auto;
            padding: 20px;
            background-color: #fefefe;
            border: 1px solid #888;
            width: 80%;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
   
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0" id="navData">
           
        </nav>
         
                  <?php
                            $ret = mysqli_query($con, "SELECT * FROM `resume` where `phone` = '$cell'");
                             $row = mysqli_fetch_array($ret); 
                              if($row) {
                             ?>
        <!-- About Start -->
        <div class="container-xxl py-5">
            <!-- Spinner Start -->
        <div id="spinner"
            class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->
            <div class="container">
                <div class="mb-3"> 
                        <label class="form-label">Name نام</label>
                        <input type="text" class="form-control" name="name" id="name" value = "<?php echo htmlentities(($row['name'])); ?>" placeholder="Enter your Name" oninput="this.value = this.value.replace(/[^A-Za-z ]/g, '')" title="Please enter uppercase letters only" />

                </div>
                <div class="mb-3">
                    <label class="form-label">Guardian سرپرست</label>
                    <input type="text" class="form-control" name="guardian" id="guardian" value = "<?php echo htmlentities(strtoupper($row['guardian'])); ?>" placeholder="Father/Husband" oninput="this.value = this.value.replace(/[^A-Za-z ]/g, '')">
                </div>
                <div class="mb-3">
                    <label class="form-label">Whatsapp Number واٹس ایپ نمبر</label><img width="25" height="25"
                        src="https://img.icons8.com/color/48/whatsapp--v1.png" alt="whatsapp--v1" />
                    <input type="text" class="form-control" value = "<?php echo htmlentities(($row['guardian'])); ?>" name="whatsapp" id="whatsapp" placeholder="Whatsapp Number"
                        maxlength="11" oninput="this.value = this.value.replace(/[^+0-9 ]/g, '')">
                </div>
                <div class="mb-3">
                <label class="form-label">Email ای میل</label>
                    <input type="email" class="form-control" value = "<?php echo htmlentities(($row['email'])); ?>" name="email" id="email" placeholder="Enter your email" >
                </div>
                <div class="mb-3">
                <label class="form-label">Address پتہ</label>
                    <input type="text" class="form-control" name="Address" id="Address" value = "<?php echo htmlentities(($row['address'])); ?>" placeholder="Enter your Address">
                </div>
                <input type="hidden" id="userCell" value = "<?php echo $cell;?>">
                <div class="mb-3">
                <label class="form-label">Profession پیشہ </label>
                    <input type="text" class="form-control" name="Profession" id="Profession" oninput="this.value = this.value.replace(/[^A-Za-z ]/g, '')" value= "<?php echo htmlentities(($row['post'])); ?>" placeholder="Profession"  >
                </div>
                <div class="mb-3">
                <label class="form-label">About Me میرے بارے میں</label>
                    <input type="text" value="<?php echo htmlentities(($row['about_Me'])); ?>" class="form-control" name="About_Me" id="About_Me"
                        placeholder="Tell us about yourself" oninput="this.value = this.value.replace(/[^A-Za-z0-9 ]/g, '')">
                </div>
                <div class="mb-6">
                    <div class="form-group">
                    <label class="form-label">Work Experiance: کام کا تجربہ</label>
                        <select name="Work_Experiance" id="Work_Experiance" required class="selectpicker show-tick form-control"
                            data-live-search="false" data-selected-text-format="count > 3" data-done-button="true"
                            data-done-button-text="OK" data-none-selected-text="All">
                            <option value="Less_then_6" selected>Less then 6 month</option>
                            <option value="1Year">1 Year</option>
                            <option value="2Year">2 year</option>
                            <option value="3Year">3 year</option>
                            <option value="4Year">4 year</option>
                            <option value="5Year">5 year</option>
                        </select>
                    </div>
                </div>
                <div class="mb-6">
                    <div class="form-group">
                    <label class="form-label">Education: تعلیم</label>
                        <select name="credentials" id="credentials" required class="selectpicker show-tick form-control"
                            data-live-search="false" data-selected-text-format="count > 3" data-done-button="true"
                            data-done-button-text="OK" data-none-selected-text="All">
                            <option value="Matric">Matric</option>
                            <option value="Intermediate">Intermediate</option>
                            <option value="Bachelors">Bachelor's</option>
                            <option value="Masters">Masters</option>
                            <option value="Mphil">Mphil</option>
                            <option value="Phd">Phd</option>
                        </select>
                    </div>
                </div>
                <div class="mb-6">
                <label class="form-label">Languages زبانیں</label>
                    <input type="text" name="Languages" id="Languages" value="<?php echo htmlentities(($row['languages'])); ?>" class="form-control"  oninput="this.value = this.value.replace(/[^A-Za-z]/g, '')">
                </div>

                <div class="mb-6 input-group mt-1">
                    <input type="number" class="form-control" value = "<?php echo htmlentities(($row['expected_salary'])); ?>" name="Expected_salary" id="Expected_salary" placeholder="Expected Salary">
                    <div class="input-group-append">
                        <select class="form-select" name="currency">
                            <option value="PKR">PKR</option>
                            <option value="USD">USD</option>
                            <option value="Pound">Pound</option>
                            <option value="Daharam">Daharam</option>
                            <option value="Rayal">Rayal</option>
                            <!-- Add more currency options as needed -->
                        </select>
                    </div>
                </div>
                <div class="mb-6 input-group mt-1">
                    <input type="number" class="form-control" value = "<?php echo htmlentities(($row['current_salary'])); ?>" name="Current_salary" id="Current_salary" placeholder="Current Salary">
                    <div class="input-group-append">
                        <select class="form-select" name="currency">
                            <option value="PKR">PKR</option>
                            <option value="USD">USD</option>
                            <option value="Pound">Pound</option>
                            <option value="Daharam">Daharam</option>
                            <option value="Rayal">Rayal</option>
                            <!-- Add more currency options as needed -->
                        </select>
                    </div>
                </div>
                <div class="mb-6">
                    <div class="form-group">
                    <label class="form-label" >City of Interest : دلچسپی کا شہر</label>
                        <select name="interest" id="interest" required class="selectpicker show-tick form-control"
                            data-live-search="false" data-selected-text-format="count > 3" data-done-button="true"
                            data-done-button-text="OK" data-none-selected-text="All">
                            <option value="None" selected>None</option>
                            <option value="Lahore">Lahore</option>
                            <option value="Islamabad">Islamabad</option>
                            <option value="Multan">Multan</option>
                            <option value="Bahawalnagar">Bahawalnagar</option>
                            <option value="karachi">karachi</option>
                            <option value="Khanewal">Khanewal</option>
                        </select>
                    </div>
                </div>

                <div class="mb-6">
                    <div class="form-group">
                    <label class="form-label">Country ملک</label>
                        <select name="country" id="country" required class="selectpicker show-tick form-control"
                            data-live-search="true">
                            <option disabled value="">Select</option>
                            <option value="Pakistan">Pakistan</option>
                            <option value="Saudi Arabia">Saudi Arabia</option>
                            <option value="Canada">Canada</option>
                            <option value="USA">USA</option>
                            <option value="England">England</option>
                            <option value="France">France</option>
                        </select>
                    </div>
                </div> 

                <div class="mb-3 mt-3">
                    <div class="col-md-6">
                        <div class="form-group">
                        <label class="form-label">Projects/Works پروجیکٹس/کام</label>
                            <input name="Works" id="Works" value = "<?php echo htmlentities(($row['projects'])); ?>" type="text" class="form-control"
                                placeholder="Provide proof of your work" oninput="this.value = this.value.replace(/[^A-Za-z ]/g, '')" >
                        </div>
                    </div>
                </div> 
  
                </div>
                <div class="col-sm-6">
                    <button type="submit" name="submit" onclick = "resume_update()" class="btn btn-primary btn-lg">Update Cv</button>
                </div> 
            </div>
        </div>
    </div>
    <?php }?> 
    <img width="40" height="40" id="scrollButton" onclick="openModal()" src="https://img.icons8.com/sf-black-filled/64/40C057/help.png" alt="help">

    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <video width="100%" height="auto" controls>
                <source src="your-video-file.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
    </div>
 
    <input type="hidden" id="screenName" value="update_resume.php">
    
    <script src="./css/code.jquery.com_jquery-3.4.1.min.js"></script>
    <script src="./css/cdn.jsdelivr.net_npm_bootstrap@5.0.0_dist_js_bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script> 
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
     
    <script src="js/main.js"></script>
  
  <script>
    $(document).ready(function() {
        screenInsert();
        navBar();
      $("#button").on('click', () => {
        $("#div").toggle();
      }); 
    });
    window.onscroll = function () {
            scrollFunction();
        };
        function openModal() {
            var modal = document.getElementById('myModal');
            modal.style.display = 'block';
        }

        function closeModal() {
            var modal = document.getElementById('myModal');
            modal.style.display = 'none';
        }

//////////////////////////////////////////////// Scroll function /////////////////////////////////////////////////////////

        function scrollFunction() {
            var scrollButton = document.getElementById("scrollButton");

            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                scrollButton.style.display = "block";
            } else {
                scrollButton.style.display = "none";
            }
        }
    function screenInsert(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/screenInsert.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                    if (data == 200) { 
                        render();
                    }else{
                        render();
                    }

                },

            });
    }
        function render(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/render.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                

                },

            });
    }
    function navBar(){ 
        $.ajax({
            type: "GET",
            url: "./backend/navBar/navBar.php",
            data: {  },
            success: function (data) {
                if (data == 200) {

                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="resume.php" class="nav-item nav-link">view resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';

                   
                          $("#navData").append(html);
                }else {
                    
                    
                    
                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;"/></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="add_Cv.php" class="nav-item nav-link">Add resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';

                    $("#navData").append(html); 
                }

            },

        });
    }
 
            function resume_update() { 
                
                var userCell            = document.getElementById("userCell").value; 
                var name            = document.getElementById("name").value; 
                var guardian        = document.getElementById("guardian").value; 
                var whatsapp        = document.getElementById("whatsapp").value; 
                var email           = document.getElementById("email").value; 
                var Address         = document.getElementById("Address").value; 
                var Profession      = document.getElementById("Profession").value; 
                var About_Me        = document.getElementById("About_Me").value; 
                var Work_Experiance = document.getElementById("Work_Experiance").value; 
                var credentials     = document.getElementById("credentials").value; 
                var Languages       = document.getElementById("Languages").value; 
                var Expected_salary = document.getElementById("Expected_salary").value; 
                var Current_salary  = document.getElementById("Current_salary").value; 
                var interest        = document.getElementById("interest").value; 
                var country         = document.getElementById("country").value; 
                var Works           = document.getElementById("Works").value; 

                $.ajax({
                    type: "GET",
                    url: "backend/resume/update.php",
                    data: {
                        "userCell"        : userCell,
                        "name"            : name,
                        "guardian"        : guardian,
                        "whatsapp"        : whatsapp,
                        "email"           : email,
                        "Address"         : Address,
                        "Profession"      : Profession,
                        "About_Me"        : About_Me,
                        "Work_Experiance" : Work_Experiance,
                        "credentials"     : credentials,
                        "Languages"       : Languages,
                        "Expected_salary" : Expected_salary,
                        "Current_salary"  : Current_salary,
                        "interest"        : interest,
                        "country"         : country,
                        "Works"           : Works
                    },
                    success: function (data) {
                        if (data == 200) {
                            Swal.fire({
                          title: "Updated",
                          text: "Congrats your changes have been done sucessfully",
                          icon: "success",
                          confirmButtonColor: "#3085d6", 
                          confirmButtonText: "Confirm"
                        }).then((result) => {
                          if (result.isConfirmed) {
                            window.location.href='./resume.php';
                          }
                        });
                         } 
                        else {
                            Swal.fire({
                              title: "Error",
                              text: "Oops! there is some error saving your data",
                              icon: "warning",
                              confirmButtonColor: "#3085d6", 
                              confirmButtonText: "Confirm"
                            }).then((result) => {
                              if (result.isConfirmed) {
                                locationReload();
                              }
                            });
                        }
                    },
                    error: function (type, obj, msg) {
                        //alert(msg);
                    },
                });
            }

            function locationReload(){
            window.location.reload();
        } 


  </script>
</body>
</html>
