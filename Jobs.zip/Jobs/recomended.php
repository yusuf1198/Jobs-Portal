<?php 

include("./constants/db_config.php");
include("./constants/values.php");

?>
<!DOCTYPE html> 
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <title>Green Jobs</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="https://themewagon.github.io/Labsky/img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">
    <link href="./adjfr_files/css2" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="./adjfr_files/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./adjfr_files/bootstrap-icons.css">

    <!-- Libraries Stylesheet -->
    <link href="./adjfr_files/animate.min.css" rel="stylesheet">
    <link href="./adjfr_files/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="./adjfr_files/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="./adjfr_files/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;"></div>
    </div>
    <!-- Spinner End --> 
     <!-- Navbar Start -->
     <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0" id="navData">
           
        </nav>
        <!-- Navbar End -->

  
    <!-- Carousel Start -->
    <div class="container-fluid header-carousel px-0 mb-5">
        <div id="header-carousel" class="carousel slide carousel-fade" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="w-100" src="./img/recommended.jpg" alt="Image">
                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row justify-content-start">
                                <div class="col-lg-7 text-start">
                                    <h1 class="display-1 text-white animated slideInRight mb-3 mt-4"> <span style="color: black;" > Green job recommended to you</span></h1>
                                    <p class="mb-5 animated slideInRight"> </p>
                                    <a href="./applied_jobs.php" class="btn btn-primary py-3 px-5 animated slideInRight" style="border-radius: 50px;">Applied Jobs</a>
                                    <?php
                                    $ret = mysqli_query($con, "SELECT * FROM `resume` where `phone` = '$cell'");
                                     $row = mysqli_fetch_array($ret); 
                                      if($row) {
                                          ?>
                                          <a href="./resume.php" class="btn btn-primary py-3 px-5 animated slideInRight mt-3 mb-3" style="border-radius: 50px;">View Resume</a>
                                    <?php  } else { ?>
                                        <a href="./add_Cv.php" class="btn btn-primary py-3 px-5 animated slideInRight mt-3 mb-3" style="border-radius: 50px;">Add Resume</a>
                                        <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> 
            </div>  
        </div>
    </div>
    
    <!-- Carousel End --> 
    <!-- Video Modal Start -->
    <div class="modal modal-video fade" id="videoModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content rounded-0">
                <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLabel">Youtube Video</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- 16:9 aspect ratio -->
                    <div class="ratio ratio-16x9">
                        <iframe class="embed-responsive-item" src="./adjfr_files/saved_resource.html" id="video" allowfullscreen="" allowscriptaccess="always" allow="autoplay"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Video Modal End -->
    <?php
                            $ret = "SELECT * FROM `resume` where `phone` = '$cell'";
                            if(mysqli_query($con, $ret)){
                                     ?>
                            <center>
                            <b><?php $Post = htmlentities(strtoupper($row['post'])); ?></b>
                            </center>
                                <?php 
                            } 
                                     ?>
        
<div class="container py-5">
    <!-- Jobs Start -->
    <div class="tab-content">
        <div id="tab-1" class="tab-pane fade show p-0 active">
            <?php
                $ret = mysqli_query($con, "SELECT * FROM `jobs` where profession = '$Post'");
                while ($row = mysqli_fetch_array($ret)) {
            ?>
            <div class="job-item p-4 mb-4">
                <div class="row"> 
                    <div class="col-sm-12 col-md-8 ">
                        <div class="text-start">
                            <h3><b>
                                <b><?php echo htmlentities(strtoupper($row['title'])); ?></b>
                                </b></h3>
                            <hr> <!-- Line after the title -->
                            <p style="font-size: 20px;"> <img width="20" height="20" src="./img/building.png" alt="building"/>
                               <b>
                               <?php echo htmlentities(strtoupper($row['company'])); ?>
                            </b>
                               <br>
                            </p>
                        </div>
                    </div>
                    <div
                        class="col-sm-12 col-md-4 d-flex flex-column align-items-start align-items-md-end justify-content-center">

                        <span class="text-truncate me-0"><img width="20" height="20" src="./img/add-bookmark.png" alt="add-bookmark"/>
                        <?php echo htmlentities($row['status']);?>
                    </span>
                        <span class="text-truncate me-3"><img width="20" height="20" src="./img/time--v1.png" alt="time--v1"/>
                            <?php echo htmlentities($row['start_time']);?> to <?php echo htmlentities($row['end_time']);?>
                        </span>
                        
                        <span class="text-truncate me-0"><img width="20" height="20" src="./img/money-bag.png" alt="money-bag"/>
                        <?php echo htmlentities($row['Salary']);?>
                    </span>
                        <small class="text-truncate"><img width="18" height="18" src="./img/calendar.png" alt="calendar"/>
                            <b>Apply Before:</b>
                            <?php echo htmlentities($row['Apply_before']);?>
                        </small>
                        <p><img width="16" height="16" src="./img/marker.png" alt="marker" />
                            <b><span style="font-size: 15px ;" >Location:</span> </b><?php echo htmlentities($row['adress']); ?>
                        <br>
                        <small class="text-truncate"><img width="18" height="18" src="./img/calendar.png" alt="calendar"/>
                            <b>Posted on:</b>
                            <?php echo htmlentities($row['created_on']);?>
                        </small>
                         
                        
                              <?php

                                $query = "SELECT * FROM `resume` WHERE `phone` = '$cell'";
                                $result = mysqli_query($con, $query);

                                if (mysqli_num_rows($result) > 0) {
                            ?>
                                    <div class="d-flex mb-3"> 
                                        <a class="btn btn-primary" href="apply_job.php?jobid=<?php echo htmlentities($row['id']); ?>">Apply Now</a>
                                    </div>
                            <?php
                                } else {
                            ?>
                                    <div class="d-flex mb-3"> 
                                        <a class="btn btn-primary" href="add_Cv.php">Add CV first</a>
                                    </div>
                            <?php
                                }
                            ?>
                      
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Jobs End -->
</div>
</div>
</div>
<?php 
                } 
            ?>
            <input type="hidden" id="screenName" value="recommended.php">
    <!-- JavaScript Libraries -->
    <script src="./adjfr_files/jquery.min.js.download"></script>
    <script src="./adjfr_files/bootstrap.bundle.min.js.download"></script>
    <script src="./adjfr_files/wow.min.js.download"></script>
    <script src="./adjfr_files/easing.min.js.download"></script>
    <script src="./adjfr_files/waypoints.min.js.download"></script>
    <script src="./adjfr_files/counterup.min.js.download"></script>
    <script src="./adjfr_files/owl.carousel.min.js.download"></script>

    <!-- Template Javascript -->
    <script src="./adjfr_files/main.js.download"></script>
    <script>
          $(document).ready(function () {
            screenInsert();
            navBar(); 
            mainButtons(); 
            
        });
        function screenInsert(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/screenInsert.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                    if (data == 200) { 
                        render();
                    }else{
                        render();
                    }

                },

            });
    }
        function render(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/render.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                

                },

            });
    }
    function navBar(){ 
        $.ajax({
            type: "GET",
            url: "./backend/navBar/navBar.php",
            data: {  },
            success: function (data) {
                if (data == 200) {

                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="resume.php" class="nav-item nav-link">view resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';

                   
                          $("#navData").append(html);
                }else {
                    
                    
                    
                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;"/></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="add_Cv.php" class="nav-item nav-link">Add resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';

                    $("#navData").append(html); 
                }

            },

        });
    }
</script>

</body></html>