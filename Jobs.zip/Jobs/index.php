<?php 

include("./constants/db_config.php");
include("./constants/values.php");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Green Jobs</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">


    <link href="./css/first_link.css" rel="stylesheet">
    <link href="./css/second_link.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">  

<style>
    
  @import url('./css/fonts_links.css'); 

.container-fluid {
    font-family: 'Noto Nastaliq Urdu', serif;
}
</style>
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner"
            class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar Start -->
        <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0" id="navData"> 
            
        </nav>
        <!-- Navbar End -->


        <!-- Carousel Start -->
        <div class="container-fluid p-0">
            <div class="owl-carousel header-carousel position-relative">
                <div class="owl-carousel-item position-relative">
                    <img class="img-fluid" src="./img/C1.jpeg" alt="" style="height: 338px;">
                    <div class="position-absolute top-0 start-0 w-100 h-10 d-flex align-items-center"
                        style="background: rgba(43, 57, 64, .5);">
                        <div class="container">
                            <div class="row justify-content-start">
                                <div class="col-10 col-lg-8">
                                    <h1 class="display-3 text-white animated slideInDown mb-4">Find The Perfect Job That
                                        You Deserved</h1><span style="color: white;">Green Jobs</span>
                                    <p class="fs-1 fw-medium text-white mb-4 pb-2">"نوکریوں کا بہت وسیع مجموعہ پیش کرتا
                                        ہے جو آپ کے مہارتوں اور ترجیحات کے مطابق ہوتے ہیں۔"</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="owl-carousel-item ">
                    <img class="img-fluid" src="./img/C2.jpeg" alt="" style="height: 338px;">
                    <div class="position-absolute top-0 start-0 w-100 h-10 d-flex align-items-center"
                        style="background: rgba(43, 57, 64, .5);">
                        <div class="container">
                            <div class="row justify-content-start">
                                <div class="col-10 col-lg-8">
                                    <h1 class="display-3 text-white animated slideInDown mb-4">Find what you need. Find
                                        what you Deserve</h1><span style="color: white;">Green Jobs</span>
                                    <p class="fs-1 fw-medium text-white mb-4 pb-2">"نوکریوں کا بہت وسیع مجموعہ پیش کرتا
                                        ہے جو آپ کے مہارتوں اور ترجیحات کے مطابق ہوتے ہیں۔</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <input type="hidden" id="userCell" value="<?php echo $cell?>">
        <!-- Jobs Start -->
        <div class="container-xxl mt-3" id="mainButtons" >
            <a href="./add_job.php"><button type="button" class="btn btn-outline-success" style="margin-left: 50px;">Add
                    job</button></a>  
                    </div>
            <div class="container py-5"> 
                <div class="tab-content">
                    <div id="tab-1" class="tab-pane fade show p-0 active">
                        <div id="showData">

                        </div>
                    </div>
                </div>
                <!-- Jobs End -->
            </div>
        </div>
    </div> 
  
<input type="hidden" id="screenName" value="index.php"> 

    <!-- JavaScript Libraries -->
    <script src="./css/code.jquery.com_jquery-3.4.1.min.js"></script>
    <script src="./css/cdn.jsdelivr.net_npm_bootstrap@5.0.0_dist_js_bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script> 
    <script src="js/main.js"></script>
    <script>
        $(document).ready(function () {
            screenInsert(); 
            navBar();
            allJobs();
            mainButtons(); 
            userCount(); 

        });
        
        function userCount(){ 
            // alert("something");
            // var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/userCount.php",
                data: {
                    // "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                    if (data == 200) { 
                        // alert("something");
                    }else{
                        // alert("nothing");
                    }

                },

            });
    }
        function screenInsert(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/screenInsert.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                    if (data == 200) { 
                        render();
                    }else{
                        render();
                    }

                },

            });
    }
        function render(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/render.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                

                },

            });
    }
        function mainButtons(){ 
        $.ajax({
            type: "GET",
            url: "./backend/navBar/buttons.php",
            data: {  },
            success: function (data) {
                if (data == 200) {

                    var html = '<a href="./resume.php"><button type="button" class="btn btn-outline-success"style="margin-left: 40px;">Resume</button></a> ';

                   
                          $("#mainButtons").append(html);
                }else {
                    
                    
                    
                    var html = '<a href="./add_Cv.php"><button type="button" class="btn btn-outline-success"style="margin-left: 50px;">Resume</button></a> ';

                    $("#mainButtons").append(html); 
                }

            },

        });
    }
    
        function navBar(){ 
        $.ajax({
            type: "GET",
            url: "./backend/navBar/navBar.php",
            data: {  },
            success: function (data) {
                if (data == 200) {

                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./testing.php" class="nav-item nav-link">Skill test</a><a href="./recomended.php" class="nav-item nav-link">Recommended Jobs</a><a href="resume.php" class="nav-item nav-link">view resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';

                   
                          $("#navData").append(html);
                }else {
                    
                    
                    
                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;"/></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./testing.php" class="nav-item nav-link">Skill test</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="add_Cv.php" class="nav-item nav-link">Add resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';

                    $("#navData").append(html); 
                }

            },

        });
    }
    

        function allJobs() {
            var userCell = document.getElementById("userCell").value;

            $.ajax({
                type: "POST",
                url: "./backend/index/index_div.php",
                data: {
                    "userCell": userCell,
                },
                success: function (data) {
                    if (data == 420) {
                        alert("error");
                    }
                    else {
                        $.each(data, function (i, item) {
                            var title = data[i].title;
                            var company = data[i].company;
                            var status = data[i].status;
                            var start_time = data[i].start_time;
                            var end_time = data[i].end_time;
                            var Salary = data[i].Salary;
                            var Apply_before = data[i].Apply_before;
                            var address = data[i].adress;
                            var created_on = data[i].created_on;
                            var button = data[i].button;
                            var j_id = data[i].j_id;  
                            if (button == 150) {
                                var html = '<div class="job-item p-4 mb-4"><div class="row"><div class="col-sm-12 col-md-8 "><div class="text-start"><h3><b><b>' + title + '</b></b></h3><hr><p style="font-size: 20px;"> <img width="20" height="20" src="./img/building.png" alt="building"/><b>' + company + '</b><br></p></div></div><div class="col-sm-12 col-md-4 d-flex flex-column align-items-start align-items-md-end justify-content-center"><span class="text-truncate me-0"><img width="20" height="20" src="./img/add-bookmark.png" alt="add-bookmark"/>' + status + '</span><span class="text-truncate me-3"><img width="20" height="20" src="./img/time--v1.png" alt="time--v1"/>' + start_time + ' to ' + end_time + '</span><span class="text-truncate me-0"><img width="20" height="20" src="./img/money-bag.png" alt="money-bag"/>' + Salary + '</span><small class="text-truncate"><img width="16" height="16" src="./img/calendar.png" alt="calendar"/><b>Apply Before:</b>' + Apply_before + '</small><p><img width="16" height="16" src="./img/marker.png" alt="marker" /><b><span style="font-size: 15px ;" >Location:</span> </b>' + address + '<br><small class="text-truncate"><img width="18" height="18" src="./img/calendar.png" alt="calendar"/><b>Posted on:</b>' + created_on + '</small><div class="d-flex mb-3"><a class="btn btn-primary" href="apply_job.php?jobid=' + j_id + '">Apply Now</a></div></div></div></div>';
                            } else {
                                var html = '<div class="job-item p-4 mb-4"><div class="row"><div class="col-sm-12 col-md-8 "><div class="text-start"><h3><b><b>' + title + '</b></b></h3><hr><p style="font-size: 20px;"> <img width="20" height="20" src="./img/building.png" alt="building"/><b>' + company + '</b><br></p></div></div><div class="col-sm-12 col-md-4 d-flex flex-column align-items-start align-items-md-end justify-content-center"><span class="text-truncate me-0"><img width="20" height="20" src="./img/add-bookmark.png" alt="add-bookmark"/>' + status + '</span><span class="text-truncate me-3"><img width="20" height="20" src="./img/time--v1.png" alt="time--v1"/>' + start_time + ' to ' + end_time + '</span><span class="text-truncate me-0"><img width="20" height="20" src="./img/money-bag.png" alt="money-bag"/>' + Salary + '</span><small class="text-truncate"><img width="18" height="18" src="./img/calendar.png" alt="calendar"/><b>Apply Before:</b>' + Apply_before + '</small><p><img width="20" height="20" src="./img/marker.png" alt="marker" /><b><span style="font-size: 15px ;" >Location:</span> </b>' + address + '<br><small class="text-truncate"><img width="18" height="18" src="./img/calendar.png" alt="calendar"/><b>Posted on:</b>' + created_on + '</small><div class="d-flex mb-3"><a class="btn btn-primary" href="add_Cv.php">Add CV first</a></div></div></div></div>';

                            }

                             
                            $("#showData").append(html);
                        });
                    }


                },
                error: function (type, obj, msg) {
                    //alert(msg);
                },
            });
        }

        let response = Android.getTokenFromSQLite();
        let deviceInfoArray = response.split("~@~");
        var userRegisteredCell = deviceInfoArray[0];

        $.ajax({
            type: "GET",
            url: "./constants/setCellNumber.php",
            data: {
                "userRegisteredCell": userRegisteredCell
            },
            success: function (data) {
                if (data == 200) {
                    setInterval(locationReload, 100);
                }

            },

        });


    

    </script>
</body>

</html>