<?php 
include("./constants/db_config.php");

      $TableId                       = $_GET['TableId'];
      $Remarks                      = $_GET['Remarks']; 
      $dropdown                      = $_GET['dropdown']; 
      
        $Query = "UPDATE `req_jobs` SET `remarks`='$dropdown',`response`='$Remarks' WHERE `id` ='$TableId'";
 
      $data = '';
       $result= mysqli_query($con,$Query);
       if($dropdown == 'Rejected'){
        $data = 204;
       }
       elseif($dropdown == 'Approved'){
        $data = 200;
       }
        
      header('content-type: application/json');
      echo json_encode($data);

?>