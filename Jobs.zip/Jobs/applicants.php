<!DOCTYPE html>
<html lang="en">
<?php 

include("./constants/db_config.php");

$ResultId = htmlspecialchars($_GET['jobid']);
include("./constants/values.php");



 
?> 
<head>
    <meta charset="utf-8">
    <title>Green Job</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <link href="./css/first_link.css" rel="stylesheet"> 
    <link href="./css/second_link.css" rel="stylesheet">  
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet"> 
    <link href="css/bootstrap.min.css" rel="stylesheet"> 
    <link href="css/style.css" rel="stylesheet">
    <style>
        /* CSS */
        .alert {
            padding: 35px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }

        .alert-info {
            color: #0c5460;
            background-color: #d1ecf1;
            border-color: #bee5eb;
        }
    </style>
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner"
            class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


      <!-- Navbar Start -->
      <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0" id="navData">
          
        </nav>
        <!-- Navbar End -->



        <!-- no record fount modal -->
        <div class="modal" id="noRecordsModal" tabindex="-1" aria-labelledby="noRecordsModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="noRecordsModalLabel">No Records Found</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" style="display: flex; justify-content: center;">
                        <img width="44" height="44" src="./img/error.png" alt="error" />
                        <p>Sorry, no records were found.</p>
                        <img width="44" height="44" src="./img/error.png" alt="error" />
                    </div>
                </div>
            </div>
        </div>
        <!-- no record fount modal end -->


        <!-- Header End -->
        <h1 class="text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">Applicants</h1>
        <div id="tab-1" class="tab-pane fade show p-0 active">
            <!-- Jobs Start -->
            <div class="tab-content">
                <div id="tab-1" class="tab-pane fade show p-0 active">
                    <?php
// Fetch a single job entry corresponding to $ResultId
$result = mysqli_query($con, "SELECT * FROM `req_jobs` WHERE j_id = $ResultId LIMIT 1");
$row = mysqli_fetch_assoc($result);

if ($row) {
?>
                    <div class="job-item p-4 mb-4">
                        <div class="row">
                            <div class="col-sm-12 col-md-8 ">
                                <div class="text-start">
                                    <h6><b>
                                            <b>
                                                <?php echo htmlentities(strtoupper($row['j_title'])); ?>
                                            </b>
                                        </b></h6>
                                    <hr> <!-- Line after the title -->
                                    <p><img width="20" height="20" src="./img/building.png" alt="building" />
                                        <b>
                                            <?php echo htmlentities(strtoupper($row['j_company'])); ?>
                                        </b> <br>
                                    </p>
                                </div>
                            </div>
                            <div
                                class="col-sm-12 col-md-4 d-flex flex-column align-items-start align-items-md-end justify-content-center">

                                <span class="text-truncate me-3"><img width="20" height="20"
                                        src="./img/add-bookmark.png" alt="add-bookmark" />
                                    <?php echo htmlentities($row['j_status']);?>
                                </span>
                                <span class="text-truncate me-3"><img width="20" height="20" src="./img/time--v1.png"
                                        alt="time--v1" />
                                    <?php echo htmlentities($row['j_strt_timing']);?> to <?php echo htmlentities($row['j_end_timing']);?> 
                                </span>
                                <span class="text-truncate me-0"><img width="20" height="20" src="./img/money-bag.png" alt="money-bag"/>
                                    <?php echo htmlentities($row['j_salary']);?>
                                </span>
                                <small class="text-truncate"><img width="18" height="18" src="./img/calendar.png" alt="calendar"/>
                                    <b>Apply Before:</b>
                                    <?php echo htmlentities($row['apply_before']);?>
                                </small>
                                <p><img width="16" height="16" src="./img/marker.png" alt="marker" />
                                    <b><span style="font-size: 15px ;" >Location:</span>  </b>
                                    <?php echo htmlentities($row['j_address']); ?>
                                    <br>
                                    <b><img width="18" height="18" src="./img/calendar.png" alt="calendar"/>Posted on:</b>
                                    <?php echo htmlentities($row['created_on']);?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <?php 
} 
?>
                </div>
            </div>
            <!-- Jobs End -->
        </div>
    </div>
    </div>
    </div>
      <!-- MPIN Form Action Sheet -->
      <div class="modal fade modalbox" id="exampleModal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content" style="background-color: #00B074;">
                    <div >
                        <a href="javascript:;" data-bs-dismiss="modal" class="headerButton ">
                            <ion-icon name="chevron-back-outline"></ion-icon>
                        </a> 
                    </div>
                    <h3 class="mx:auto mt-3" style=" color: white; margin-left: 100px; font-size: 35px; ">Selection</h3> 
                    <br>
                    <div class="form-group text-center"  style=" width: 80%; margin-left: 35px; ">
                        <label for="dropdown" style=" color: white;">Remarks</label>
                        <select class="form-control" id="dropdown">
                            <option value="Approved">Approved</option>
                            <option value="Rejected">Rejected</option> 
                        </select>
                    </div>
                    <input type="hidden" class="form-control" id="hiidenupdateid" readonly>
                    <div class="form-floating">
                        <textarea class="form-control" style = "width: 80%; margin-left: 35px;" placeholder="Leave a comment here" id="Remarks"></textarea>
                        <label for="floatingTextarea" style="margin-left: 30px;">Comments</label>
                      </div>
                    <div class="text" id="appendErrorResponseMpin"
                        style="color:red; text-align: center; font-weight: bold; text-transform: uppercase;"> 
                    </div>
                    
                    <div class="modal-body">
                        <div class="action-sheet-content "> 
                            <button type="button" onclick="modalAjax()" class="btn btn-dark btn-lg" style="width: 100%;">
                                Submit
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php
$ret = mysqli_query($con, "SELECT * FROM `req_jobs` WHERE j_id = '$ResultId'"); 
if (mysqli_num_rows($ret) > 0) {
    // $_SESSION['id']=$num['uid']; 
?>
    <!-- <table id="record" class="table table-dark table-striped-columns"> -->
    <div class="table-responsive" style="overflow-x: auto;">
        <table class="datatable-1 table table-striped display" style="width: 100%;">
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Education</th>
                    <th scope="col">Experiance</th>
                    <th scope="col"> contact no</th>
                    <th scope="col">Recommendation</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <?php
                while ($row = mysqli_fetch_array($ret)) {
                ?>
            <tbody>
                <tr>
                    <td>
                        <?php echo htmlentities($row['u_name']);?>
                    </td>
                    <td>
                        <?php echo htmlentities($row['u_education']);?>
                    </td>
                    <td>
                        <?php echo htmlentities($row['work_exp']);?>
                    </td>
                    <td>
                        <?php echo htmlentities($row['u_phone']);?>
                    </td>
                    <td>
                        <!-- <progress max="100" value="50"></progress> -->
                        <center> 
                        <img width="30" height="30"  data-toggle="modal" data-target="#progress" src="https://img.icons8.com/ios-filled/50/40C057/discount--v1.png" alt="discount--v1"/>
                        </center>
                    </td>
                    <td>
                    <?php echo htmlentities($row['remarks']);?>
                        
                    </td>
                    <td><img  type="button" onclick="modal(<?php echo htmlentities($row['id']); ?>)"  data-toggle="modal" data-target="#exampleModal" width="30" height="30" src="https://img.icons8.com/ios-glyphs/30/40C057/response.png" alt="response">
                    </td>
                </tr>
            </tbody>
            <?php
}
?>
        </table>
    </div>
    <?php
} 
else { 
echo '<script>';
echo 'document.addEventListener("DOMContentLoaded", function() {';
echo 'var myModal = new bootstrap.Modal(document.getElementById("noRecordsModal"), { backdrop: "static", keyboard: false });';
echo 'myModal.show();';
echo '});';
echo '</script>';
echo "<table id='record' class='table table-dark table-striped-columns'>";
echo "<td>No record Found</td>";
echo "</table>";
} 
 ?> 
 <div class="modal fade" id="progress" tabindex="-1" role="dialog" aria-labelledby="progressLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="progressLabel">Green Job recommend </h5> 
      </div>
      <div class="modal-body">
      <?php
                    $ret = mysqli_query($con, "SELECT * FROM `jobs`"); 
                    if (mysqli_num_rows($ret) > 0) { 
                      echo  $percentage = ($row['percentage']);  // Get the number of entries
                        ?>
        <div class="progress-circle">
          <span style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 24px; color: #3498db;">
          <?php echo htmlentities($row['percentage']);?>
          </span>
        </div>
      </div>
      <div class="modal-footer">
        <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
      </div>
    </div>
  </div>
</div>

<?php
   }
  ?>
    </div> 
    <input type="hidden" id="screenName" value="applicants.php">
    <!-- JavaScript Libraries -->
    <script src="./css/code.jquery.com_jquery-3.4.1.min.js"></script>
    <script src="./css/cdn.jsdelivr.net_npm_bootstrap@5.0.0_dist_js_bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="./online_links/ajax.googleapis.com_ajax_libs_jquery_3.5.1_jquery.min.js"></script>
    <script src="./online_links/cdnjs.cloudflare.com_ajax_libs_popper.js_1.16.0_umd_popper.min.js"></script>
    <script src="./online_links/last.js"></script> 
    <script src="js/main.js"></script>
    <script src="./online_links/cdn.jsdelivr.net_npm_sweetalert2@11"></script>

<script>
    
    $(document).ready(function() {
        navBar();
        screenInsert();
      $("#button").on('click', () => {
        $("#div").toggle();
      });
      $('#example-select').multiselect({
        // Add your plugin configurations here
        buttonWidth: '200px',
        // Add more configurations as needed
      });
    });
    function screenInsert(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/screenInsert.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                    if (data == 200) { 
                        render();
                    }else{
                        render();
                    }

                },

            });
    }
        function render(){ 
            // alert("something");
            var screenName = document.getElementById("screenName").value;
            // var accessDate = document.getElementById("accessDate").value;
              $.ajax({
                type: "GET",
                url: "./backend/index/render.php",
                data: {
                    "screenName": screenName, 
                    // "accessDate": accessDate,
                },
                success: function (data) {
                

                },

            });
    }
   function modal(modalrowid) {
        var editid = modalrowid;
        document.getElementById("hiidenupdateid").value=editid;
   }
   function navBar(){ 
        $.ajax({
            type: "GET",
            url: "./backend/navBar/navBar.php",
            data: {  },
            success: function (data) {
                if (data == 200) {

                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="resume.php" class="nav-item nav-link">view resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';

                   
                          $("#navData").append(html);
                }else {
                    
                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="add_Cv.php" class="nav-item nav-link">Add resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';
                    
                    $("#navData").append(html); 
                }

            },

        });
    }
// //////////////////////////////////////////////////////////////////////////////////////////////////
   function modalAjax() {  
    var TableId = document.getElementById("hiidenupdateid").value;
    var Remarks = document.getElementById("Remarks").value; 
    var dropdown = document.getElementById("dropdown").value; 
    
     
        $.ajax({
            type: "GET",
            url: "./modalAjax.php",
            data: {
                "TableId": TableId,
                "Remarks": Remarks,
                "dropdown": dropdown
            },
            success: function(data) {
                if (data == 200) {   

                    Swal.fire({
                      title: "Are you sure?",
                      text: "We are glad we helped you find someone",
                      icon: "success",
                      confirmButtonColor: "#3085d6", 
                      confirmButtonText: "Confirm"
                    }).then((result) => {
                      if (result.isConfirmed) {
                        locationReload();
                      }
                    });

                }  
                if (data == 204) {   
                    Swal.fire({
                      title: "Are you sure?",
                      text: "This is directly be sent to the user",
                      icon: "warning",
                      confirmButtonColor: "#3085d6", 
                      confirmButtonText: "Confirm"
                    }).then((result) => {
                      if (result.isConfirmed) {
                        locationReload();
                      }
                    });
                                            // locationReload(); 
                }  
                 
            },
             
        });
    }
    function locationReload(){
        window.location.reload();
    }
</script>
</body>

</html>