<?php
date_default_timezone_set("Asia/Karachi");
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET,HEAD,OPTIONS,POST,PUT");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization");

// $obj = json_decode(file_get_contents("php://input"), true);

 $type                  = $_POST['type']; 
 $date                  = $_POST['date']; 
 $Company_name          = $_POST['Company_name']; 
 $Job_title             = $_POST['Job_title']; ;
 $customerAddress       = $_POST['customerAddress']; 
 $Profession       = $_POST['Profession']; 
 $Salary_range          = $_POST['Salary_range']; 
 $jobtype               = $_POST['jobtype']; ;
 $Education             = $_POST['Education']; 
 $experience            = $_POST['experience'];
 $country               = $_POST['country']; 
 $starting                    = $_POST['starting'];
 $ending                    = $_POST['ending']; 
 $amount                = $_POST['amount']; 
 $userId                  = $_POST['userId'];
 $userCell                = $_POST['userCell']; 
 $userName                = $_POST['userName']; 
 $userCity                = $_POST['userCity']; 
 $pincode                 = $_POST['Mpin']; 
 $userRegisteredCell      = $_POST['userRegisteredCell']; 
 $userRegistDeviceString  = $_POST['userRegistDeviceString']; 
 $userRegistSecureId      = $_POST['userRegistSecureId']; 
 $userRegistPhoneModel    = $_POST['userRegistPhoneModel']; 
 $pp_MobileNumber         = $_POST['number']; 
 $serviceCharges          = "0";
 $serviceChargesPay       = "0";
 $retailer_Amount         = "0";
 $profitPolicy            = "0";
 $userRegisteredLat       = "0";
 $userRegisteredLng       = "0";
 $created_on              = strtotime(date("Y-m-d"))*1000;
 $actualDate              = date('Y-m-d H:i:s');
 $currentTime              = date('Y-m-d H:i');
 $time                    = date('dHis');
 $dateFileSaving          = date('Y-m-d');
 $dealStatus              = "purchasing";

session_start();
/////////////// secure api code /////////////////////////
include("../constants/db_config.php");
                  $toUserId                   = "30";
                  $toUserName                 = "Green Store";
                  $toUserCell                 = "03357628509";
                  $userBalance                = "0";
                  $userType                   = "Coorporate";
                  $isSalesman                 = "user";  
                  $r_recommender_cell_number  = "03321799998";
                  $recommender_cell_number    = "03321799998"; 
                  //***************************PAYMENT METHOD START *****************************
                  $ajaxLinkJazzCash = "http://eduvalley.pk/greenApp/ajaxApi/sendEasyPaisaCall.php";
                  $curl = curl_init();
                  curl_setopt_array($curl, array(
                    CURLOPT_URL => $ajaxLinkJazzCash,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS =>'{
                        "userId": "'.$toUserId.'",
                        "userCell": "'.$toUserCell.'",
                        "userName": "'.$toUserName.'",
                        "userType": "'.$userType.'",
                        "isSalesman": "'.$isSalesman.'",
                        "r_recommender_cell_number": "'.$r_recommender_cell_number.'",
                        "recommender_cell_number": "'.$recommender_cell_number.'",
                        "userBalance": "'.$userBalance.'",
                        "pincode": "'.$pincode.'",
                        "userRegistDeviceString": "'.$userRegistDeviceString.'",
                        "serRegistSecureId": "'.$userRegistSecureId.'",
                        "userRegistPhoneModel": "'.$userRegistPhoneModel.'",
                        "pp_MobileNumber": "'.$pp_MobileNumber.'",
                        "pp_Amount": "'.$dealAmount.'",
                        "retailer_Amount": "'.$dealAmount.'",
                        "serviceCharges": "'.$serviceCharges.'",
                        "serviceChargesPay": "'.$serviceChargesPay.'",
                        "profitPolicy": "'.$profitPolicy.'",
                        "userRegisteredLat": "'.$userRegisteredLat.'",
                        "userRegisteredLng": "'.$userRegisteredLng.'"
                    }',
                    CURLOPT_HTTPHEADER => array(
                        'content-type: application/json',
                        'Accept: application/json'
                         ),
                    ));
                                //Execute
                                $response  = curl_exec($curl);
                                 // print_r($response);
                                //Error
                                $errUpdate = curl_error($curl);
                                curl_close($curl);
                              
                                if($errUpdate) 
                                {
                                    $data = array('message' => 'INTERNAL SERVER ERROR!! PAYMENT REJECTED Due To Internal Server Error. Sorry For Inconvenience, Please Try Again Later...', 'status' => false, 'code' => '500');
                                }else{
                                    $responseDecoded = json_decode($response);
                                    $responseCode    = $responseDecoded->code;
                                    $responseMessage = $responseDecoded->message;
                                    $responseStatus  = $responseDecoded->status;

                                    if($responseCode == "200") 
                                    {

                                        ///query and saving
                                        $query = "INSERT INTO `jobs`(`userId`, `userCell`, `userName`, `title`,`profession`,  `company`,`payment_method`, `Salary`, `experience`, `Apply_before`, `education`, `start_time`, `end_time`,  `adress`,`status`, `created_on`, `updated_on`, `deleted_on`, `cell`) VALUES ('$userId','$userCell','$userName','$Job_title','$Profession','$Company_name','$type','$Salary_range','$experience','$date','$Education','$starting','$ending','$customerAddress','$jobtype','$current_date','$current_date','0','$userCell')"; 
                                        
                                        $run1 = mysqli_query($con, $query);
                                         $data = array('message' => $responseMessage, 'status' => $responseStatus, 'code' => $responseCode);
                                                  
                                    }
                                    else 
                                    {
                                        $data = array('message' => $responseMessage, 'status' => false, 'code' => $responseCode);
                                    }
                                }
                  //***************************PAYMENT METHOD END *****************************
  header('content-type: application/json');
   json_encode($data);
?>