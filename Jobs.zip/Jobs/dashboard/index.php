<?php
include("../constants/db_config.php");
include("../constants/values.php"); 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
    <title>Admin Dashboard | Keyframe Effects</title>
    <link rel="stylesheet" href="../css/style_dashboard.css">
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
    
</head>
<body>
   <input type="checkbox" id="menu-toggle">
    <div class="sidebar">
        <div class="side-header">
            <h3>Green<span>Jobs</span></h3>
        </div>
        
        <div class="side-content">
            <div class="profile"> 
                <h4></h4>
                <small></small>
            </div>

            <div class="side-menu">
                <ul>
                    <li>
                       <a href="./index.php" class="active">
                            <span class="las la-home"></span>
                            <small>Dashboard</small>
                        </a>
                    </li>
                    <li>
                       <a href="./cv_request.php">
                            <span class="las la-user-alt"></span>
                            <small>test requests</small>
                        </a>
                    </li>
                    <li>
                       <a href="cv_test_req.php">
                            <span class="las la-envelope"></span>
                            <small>cv check request</small>
                        </a>
                    </li>
                    <li>
                       <a href="./Users.php">
                            <span class="las la-clipboard-list"></span>
                            <small>Users join</small>
                        </a>
                    </li>
                    <li>
                       <a href="">
                            <span class="las la-shopping-cart"></span>
                            <small>Resume added</small>
                        </a>
                    </li>
                    <li>
                       <a href="">
                            <span class="las la-tasks"></span>
                            <small>Tasks</small>
                        </a>
                    </li>

                </ul>
            </div>
        </div>
    </div>
    
    <div class="main-content">
<!--         
        <header>
            <div class="header-content">
                <label for="menu-toggle">
                    <span class="las la-bars"></span>
                </label>
                
                <div class="header-menu">
                    <label for="">
                        <span class="las la-search"></span>
                    </label>
                    
                    <div class="notify-icon">
                        <span class="las la-envelope"></span>
                        <span class="notify">4</span>
                    </div>
                    
                    <div class="notify-icon">
                        <span class="las la-bell"></span>
                        <span class="notify">3</span>
                    </div>
                    
                    <div class="user">
                        <div class="bg-img" style="background-image: url(img/1.jpeg)"></div>
                        
                        <span class="las la-power-off"></span>
                        <span>Logout</span>
                    </div>
                </div>
            </div>
        </header> -->
        
        
        <main>
      
            
            <div class="page-header">
                <h1>Dashboard</h1>
                <small>Home / Dashboard</small>
            </div>
            
            <div class="page-content">
            
                <div class="analytics">
                <?php
                    $ret = mysqli_query($con, "SELECT * FROM `jobs`"); 
                    if (mysqli_num_rows($ret) > 0) {
                        $numEntries = mysqli_num_rows($ret); // Get the number of entries
                        ?>
                        <div class="card">
                            <div class="card-head">
                                <h2><?php echo $numEntries; ?></h2>
                                <span class="las la-user-friends"></span>
                            </div>
                            <div class="card-progress">
                                <small>Jobs Added </small>
                                <div class="card-indicator">
                                    <div class="indicator one" style="width: <?php echo ($numEntries * 100 / 100); ?>%"></div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                ?>
                <?php
                    $ret = mysqli_query($con, "SELECT * FROM `resume`"); 
                    if (mysqli_num_rows($ret) > 0) {
                        $numEntries = mysqli_num_rows($ret); // Get the number of entries
                        ?>
                        <div class="card">
                            <div class="card-head">
                            <h2><?php echo $numEntries; ?></h2>
                                <span class="las la-eye"></span>
                            </div>
                            <div class="card-progress">
                                <small>Resume Added</small>
                                <div class="card-indicator">
                                    <div class="indicator two" style="width: 80%"></div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                ?>
                   <?php
                        $ret = mysqli_query($con, "SELECT * FROM `jobs`"); 
                        if (mysqli_num_rows($ret) > 0) {
                            $numEntries = mysqli_num_rows($ret); // Get the number of entries
                            $total = $numEntries * 50;
                            ?>
                            <div class="card">
                                <div class="card-head">
                                    <h2><?php echo $total; ?></h2>
                                    <span class="las la-shopping-cart"></span>
                                </div>
                                <div class="card-progress">
                                    <small>Revenue growth</small>
                                    <div class="card-indicator">
                                        <div class="indicator one" style="width: <?php echo ($total * 100 / 500); ?>%"></div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                    ?>
                     <?php
                        $ret = mysqli_query($con, "SELECT * FROM `usercount`"); 
                        if (mysqli_num_rows($ret) > 0) {
                            $numEntries = mysqli_num_rows($ret);   
                            ?>
                    <div class="card">
                        <div class="card-head">
                            <h2><?php echo $numEntries; ?></h2>
                            <span class="las la-envelope"></span>
                        </div>
                        <div class="card-progress">
                            <small>Total user visit</small>
                            <div class="card-indicator">
                                <div class="indicator four" style="width: 100%"></div>
                            </div>
                        </div>
                    </div> 
                    <?php
                        }
                    ?>
                </div>


                <div class="records table-responsive">

                    <div>
                        <table width="100%">
                            <thead>
                                <tr> 
                                    <th><span class=""></span> Screen #</th>
                                    <th><span class=""></span> Screen usage in total</th>
                                    <th><span class=""></span> last access date</th>
                                    <th><span class=""></span> Screen name </th>
                                </tr>
                            </thead>
                            <?php
                        $ret = ("SELECT * FROM `screens`"); 
                        $conn = mysqli_query($con,$ret);
                        while ($row = mysqli_fetch_array($conn)) {
                            // $_SESSION['id']=$num['uid']; 
                        ?>
                            <tbody>
                                <tr> 
                                    <td style="width: 400px;">
                                        <div class="client"> 
                                            <div class="client-info">
                                                <h4><?php echo htmlentities($row['id']);?> </h4> 
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                    <?php echo htmlentities($row['count']);?> 
                                    </td>
                                    </td>
                                    <td>
                                    <?php echo htmlentities($row['date']);?>
                                    </td>
                                    <td>
                                        <?php echo htmlentities($row['name']);?>
                                    </td>
                                </tr>
                            </tbody>
                            <?php
                    }
                            ?>
                        </table>
                    </div>

                </div>
            
            </div>
            
        </main>
        
    </div>
</body>
</html>