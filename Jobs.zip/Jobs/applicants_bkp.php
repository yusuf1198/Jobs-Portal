<!DOCTYPE html>
<html lang="en">
<?php 

include("./constants/db_config.php");

$ResultId = htmlspecialchars($_GET['jobid']);
include("./constants/values.php");



 
?> 
<head>
    <meta charset="utf-8">
    <title>Green Job</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <link href="./css/first_link.css" rel="stylesheet"> 
    <link href="./css/second_link.css" rel="stylesheet">  
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet"> 
    <link href="css/bootstrap.min.css" rel="stylesheet"> 
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="./js/sweetalert.js">
    <style>
        /* CSS */
        .alert {
            padding: 35px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }

        .alert-info {
            color: #0c5460;
            background-color: #d1ecf1;
            border-color: #bee5eb;
        }
    </style>
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner"
            class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


      <!-- Navbar Start -->
      <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0" id="navData">
          
        </nav>
        <!-- Navbar End -->



        <!-- no record fount modal -->
        <div class="modal" id="noRecordsModal" tabindex="-1" aria-labelledby="noRecordsModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="noRecordsModalLabel">No Records Found</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" style="display: flex; justify-content: center;">
                        <img width="44" height="44" src="./img/error.png" alt="error" />
                        <p>Sorry, no records were found.</p>
                        <img width="44" height="44" src="./img/error.png" alt="error" />
                    </div>
                </div>
            </div>
        </div>
        <!-- no record fount modal end -->


        <!-- Header End -->
        <h1 class="text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">Applicants</h1>
        <div id="tab-1" class="tab-pane fade show p-0 active">
            <!-- Jobs Start -->
            <div class="tab-content">
                <div id="tab-1" class="tab-pane fade show p-0 active">
                     
                    <div class="job-item p-4 mb-4">
                        <div class="row">
                        <div id="jobData">

                            
                        </div>
                       </div>
                    </div>
                    
                </div>
            </div>
            <!-- Jobs End -->
        </div>
    </div>
    </div>
    </div>
    <!-- Modal for Status updation start -->
  
    <!-- <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Job Application</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                     
                    <div class="form-group">
                            <label for="dropdown">Remarks</label>
                            <select class="form-control" id="dropdown">
                                <option value="Approved">Approved</option>
                                <option value="Rejected">Rejected</option> 
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="inputField">Remarks</label>
                            <input type="text" class="form-control" id="Remarks" placeholder="Enter something" required>
                        </div>
                        <div class="form-group"> 
                            <input type="hidden" class="form-control" id="hiidenupdateid" readonly> 
                        </div>
                       <input type="submit" onclick="modalAjax()" name ="submit" value= "Submit"> 
                </div> 
            </div>
        </div>
    </div>  -->
    <!-- Modal for Status updation start -->
     <!-- MPIN Form Action Sheet -->

     <div class="modal fade modalbox" id="exampleModal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content" style="background-color: #00B074;">
                    <div >
                        <a href="javascript:;" data-bs-dismiss="modal" class="headerButton ">
                            <ion-icon name="chevron-back-outline"></ion-icon>
                        </a> 
                    </div>
                    <h3 class="mx:auto mt-3" style=" color: white; margin-left: 100px; font-size: 35px; ">Selection</h3> 
                    <br>
                    <div class="form-group text-center"  style=" width: 80%; margin-left: 35px; ">
                        <label for="dropdown" style=" color: white;">Remarks</label>
                        <select class="form-control" id="dropdown">
                            <option value="Approved">Approved</option>
                            <option value="Rejected">Rejected</option> 
                        </select>
                    </div>
                    <input type="hidden" class="form-control" id="hiidenupdateid">
                    <div class="form-floating">
                        <textarea class="form-control" style = "width: 80%; margin-left: 35px;" placeholder="Leave a comment here" id="Remarks"></textarea>
                        <label for="floatingTextarea" style="margin-left: 30px;">Comments</label>
                      </div>
                    <div class="text" id="appendErrorResponseMpin"
                        style="color:red; text-align: center; font-weight: bold; text-transform: uppercase;"> 
                    </div>
                    
                    <div class="modal-body">
                        <div class="action-sheet-content "> 
                            <button type="button" onclick="modalAjax()" class="btn btn-dark btn-lg" style="width: 100%;">
                                Submit
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <input type="hidden" id="resultId" value = "<?php echo $ResultId; ?>">
        
    
    <!-- <table id="record" class="table table-dark table-striped-columns"> -->
    <div class="table-responsive" style="overflow-x: auto;">
        <table class="datatable-1 table table-striped display" >
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Profession</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Expected salary</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
           
            <tbody id="showData">
               
            </tbody>
         
        </table>
    </div>
     
    </div> 
    <!-- JavaScript Libraries -->
    <script src="./css/code.jquery.com_jquery-3.4.1.min.js"></script>
    <script src="./css/cdn.jsdelivr.net_npm_bootstrap@5.0.0_dist_js_bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="./js/footer_link3.js"></script>
    <script src="./js/footer_link2.js"></script>
    <script src="./js/foooter_links_1.js"></script> 
    <script src="js/main.js"></script>
    <script src="./js/sweetalert.min.js"></script>
   <script src="./js/sweetalert.js"></script>

    <script>
         $(document).ready(function (){
            tableData();
            aboveData();
            navBar();

        });

        function navBar(){ 
        $.ajax({
            type: "GET",
            url: "./backend/navBar/navBar.php",
            data: {  },
            success: function (data) {
                if (data == 200) {

                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="resume.php" class="nav-item nav-link">view resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';

                          $("#navData").append(html);
                }else {
                    
                    var html = '<a href="./"><img src="./img/greenapp.png" alt="Logo" style="height: 50px;" /></a><button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="navbarCollapse"><div class="navbar-nav ms-auto p-4 p-lg-0"><a href="add_job.php" class="nav-item nav-link">Add job</a><a href="./recomended.php" class="nav-item nav-link">Recomended Jobs</a><a href="add_Cv.php" class="nav-item nav-link">Add resume</a><div class="nav-item dropdown"><a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Jobs</a><div class="dropdown-menu rounded-0 m-0"><a href="company_jobs.php" class="dropdown-item active">Your Jobs</a><a href="applied_jobs.php" class="dropdown-item">Applied Jobs</a></div><a href="https://eduvalley.pk/greenApp" class="nav-item nav-link">Go to green app</a></div></div></div></div>';
                    
                    $("#navData").append(html); 
                }

            },

        });
    }
 
       function modal(modalrowid) {
            var editid = modalrowid;
            document.getElementById("resultId").value=editid;
       }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function tableData() {
    var resultId = document.getElementById("resultId").value;

    $.ajax({
        type: "GET",
        url: "./backend/applicants/aboveData.php",
        data: {
            "resultId": resultId
        },
        success: function(data) {
            if (data == 420) {
                alert("something");
            } else {
                $.each(data, function (i, items) {
                    var title = items.j_title;
                    var j_salary = items.j_salary;
                    var apply_before = items.apply_before;
                    var j_address = items.j_address;
                    var created_on = items.created_on;
                    var j_company = items.j_company;
                    var j_status = items.j_status;
                    var j_timing = items.j_timing;
 
                    $("#jobData").append(`<div class="col-sm-12 col-md-8"><div class="text-start"><h6><b>${title}</b></h6><hr><p><img width="20" height="20" src="./img/building.png" alt="building" /><b>${j_company}</b></p></div></div><div class="col-sm-12 col-md-4 d-flex flex-column align-items-start align-items-md-end justify-content-center"><span class="text-truncate me-3"><img width="20" height="20" src="./img/add-bookmark.png" alt="add-bookmark" />${j_status}</span><span class="text-truncate me-3"><img width="20" height="20" src="./img/time--v1.png" alt="time--v1" />${j_timing}</span><span class="text-truncate me-0"><img width="20" height="20" src="./img/money-bag.png" alt="money-bag" />${j_salary}</span><small class="text-truncate"><img width="18" height="18" src="./img/calendar.png" alt="calendar"/><b>Apply Before:</b>${apply_before}</small><p><img width="20" height="20" src="./img/marker.png" alt="marker" /><b>Location: </b>${j_address}<br><b><img width="18" height="18" src="./img/calendar.png" alt="calendar"/>Posted on:</b>${created_on}</p></div></div>`);
                });
            }
        },
    });
}

 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 function aboveData() {  
        var resultId = document.getElementById("resultId").value;  
        
            $.ajax({
                type: "GET",
                url: "./backend/applicants/applicant_table.php",
                data: {
                    "resultId": resultId
                },
                success: function(data) {
                    if (data == 420) {   
                        alert("something");
                    }  else {   
                        $.each(data, function (i, item) {
                              var u_name   = item.u_name;  
                              var u_guardian   = item.u_guardian;  
                              var work_exp   = item.work_exp;  
                              var u_phone   = item.u_phone;  
                              var remarks   = item.remarks;  
                              var id   = item.id;  

                              $("#showData").append('<tr><td>'+ u_name +'</td><td>'+ u_guardian +'</td><td>'+ work_exp +'</td><td>'+ u_phone +'</td><td>'+ remarks +'</td><td><img  type="button" onclick="modal('+ id +'"  data-toggle="modal" data-target="#exampleModal" width="30" height="30" src="https://img.icons8.com/ios-glyphs/30/40C057/response.png" alt="response"></td></tr>');
                        });
         
                    } 
                },
            });
        }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 

function modal(id){
    document.getElementById('hiidenupdateid').value=id;
}
       function modalAjax() {  
        var TableId = document.getElementById("hiidenupdateid").value;
        var Remarks = document.getElementById("Remarks").value; 
        var dropdown = document.getElementById("dropdown").value; 
        
            $.ajax({
                type: "GET",
                url: "./backend/modals/modalAjax.php",
                data: {
                    "TableId": TableId,
                    "Remarks": Remarks,
                    "dropdown": dropdown
                },
                success: function(data) {
                    if (data == 200) {   
                        Swal.fire({
                          title: "Are you sure?",
                          text: "We are glad we helped you find someone",
                          icon: "success",
                          confirmButtonColor: "#3085d6", 
                          confirmButtonText: "Confirm"
                        }).then((result) => {
                          if (result.isConfirmed) {
                            locationReload();
                          }
                        });
                    }  
                    if (data == 204) {   
                        Swal.fire({
                          title: "Are you sure?",
                          text: "This is directly be sent to the user",
                          icon: "warning",
                          confirmButtonColor: "#3085d6", 
                          confirmButtonText: "Confirm"
                        }).then((result) => {
                          if (result.isConfirmed) {
                            locationReload();
                          }
                        });
                 
                    }  
                     
                },
                 
            });
        }
      
        function locationReload(){
            window.location.reload();
        }
    </script>
</body>

</html>